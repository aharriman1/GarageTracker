#!/usr/bin/env python3
"""
Garage Tracker v1.0.0
A complete local, offline desktop application for tracking everything about your vehicles.
Requires: Python 3.8+ with tkinter (standard library)
Run: python garage_tracker.py
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import sqlite3
import os
import csv
import shutil
from datetime import datetime, date, timedelta

# ============================================================
# CONSTANTS & CONFIGURATION
# ============================================================

APP_NAME    = "Garage Tracker"
APP_VERSION = "1.0.0"
DB_FILE     = os.path.join(os.path.expanduser("~"), "garage_tracker.db")

COLORS = {
    "bg_dark":      "#1a1a2e",
    "bg_medium":    "#16213e",
    "bg_light":     "#0f3460",
    "sidebar":      "#0d1b2a",
    "sidebar_hover":"#1b2838",
    "accent":       "#e94560",
    "accent2":      "#533483",
    "text_primary": "#eaeaea",
    "text_secondary":"#a0a0b0",
    "text_muted":   "#606070",
    "success":      "#4caf50",
    "warning":      "#ff9800",
    "danger":       "#f44336",
    "info":         "#2196f3",
    "border":       "#2a2a4a",
    "table_bg":     "#12122a",
    "table_alt":    "#1a1a3e",
    "table_select": "#533483",
    "entry_bg":     "#0d1b2a",
    "btn_primary":  "#e94560",
    "btn_secondary":"#533483",
    "btn_success":  "#2d6a4f",
    "btn_danger":   "#7b2d2d",
}

FONT_TITLE      = ("Segoe UI", 20, "bold")
FONT_SUBTITLE   = ("Segoe UI", 14, "bold")
FONT_LABEL      = ("Segoe UI", 10)
FONT_LABEL_BOLD = ("Segoe UI", 10, "bold")
FONT_SMALL      = ("Segoe UI", 9)

MAINTENANCE_CATEGORIES = [
    "Oil Change","Tires","Brakes","Suspension","Engine","Transmission",
    "Cooling System","Electrical","Exhaust","Interior","Exterior","Audio",
    "Detailing","Inspection","Fuel System","AC/Heat","Alignment","Battery","Other"
]
MOD_CATEGORIES = [
    "Engine","Intake","Exhaust","Tune","Suspension","Wheels/Tires","Brakes",
    "Interior","Exterior","Lighting","Audio","Electronics","Body","Custom Fabrication","Other"
]
MOD_STATUSES    = ["Idea","Planned","Parts Ordered","In Progress","Installed","Canceled"]
REPAIR_STATUSES = ["Open","Diagnosing","Waiting on Parts","Repaired","Monitoring","Unresolved"]
LABOR_BY        = ["Self","Shop","Friend","Dealership","Other"]
PRIORITIES      = ["Low","Medium","High","Critical"]
NOTE_SYSTEMS    = ["Engine","Suspension","Interior","Exterior","Electrical","Audio","Body","General","Other"]


# ============================================================
# UTILITY
# ============================================================

def today_str():
    return date.today().isoformat()

def format_currency(val):
    try:    return f"${float(val):,.2f}"
    except: return "$0.00"

def format_mileage(val):
    try:    return f"{int(val):,} mi"
    except: return ""

def validate_date(s):
    if not s: return True
    try:    date.fromisoformat(s); return True
    except: return False


# ============================================================
# DATABASE
# ============================================================

class Database:
    def __init__(self, path=DB_FILE):
        self.path = path
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self._create_tables()

    def _create_tables(self):
        c = self.conn
        c.execute("""CREATE TABLE IF NOT EXISTS vehicles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            year TEXT, make TEXT, model TEXT, trim TEXT,
            vin TEXT, license_plate TEXT, mileage INTEGER DEFAULT 0,
            engine TEXT, transmission TEXT, color TEXT,
            purchase_date TEXT, purchase_price REAL DEFAULT 0,
            current_value REAL DEFAULT 0,
            insurance_company TEXT, insurance_policy TEXT, insurance_expiry TEXT,
            registration_expiry TEXT, notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")

        c.execute("""CREATE TABLE IF NOT EXISTS maintenance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id INTEGER, date TEXT, mileage INTEGER,
            category TEXT, service TEXT, parts TEXT, fluids TEXT,
            labor_by TEXT, cost_parts REAL DEFAULT 0, cost_labor REAL DEFAULT 0,
            total_cost REAL DEFAULT 0, receipt_ref TEXT, notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE)""")

        c.execute("""CREATE TABLE IF NOT EXISTS service_schedule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id INTEGER, service_name TEXT,
            interval_miles INTEGER, interval_days INTEGER,
            last_done_date TEXT, last_done_mileage INTEGER,
            next_due_date TEXT, next_due_mileage INTEGER,
            priority TEXT DEFAULT 'Medium', notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE)""")

        c.execute("""CREATE TABLE IF NOT EXISTS modifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id INTEGER, date_installed TEXT,
            mileage_installed INTEGER, name TEXT, category TEXT,
            brand TEXT, part_number TEXT, cost REAL DEFAULT 0,
            installed_by TEXT, before_notes TEXT, after_notes TEXT,
            supporting_mods TEXT, tune_required TEXT DEFAULT 'No',
            warranty_affected TEXT DEFAULT 'No', notes TEXT,
            status TEXT DEFAULT 'Installed', priority TEXT,
            estimated_cost REAL DEFAULT 0, needed_parts TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE)""")

        c.execute("""CREATE TABLE IF NOT EXISTS repairs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id INTEGER, issue_title TEXT,
            date_noticed TEXT, mileage_noticed INTEGER,
            symptoms TEXT, trouble_codes TEXT, diagnosis_notes TEXT,
            parts_replaced TEXT, repair_steps TEXT, fixed_date TEXT,
            fixed_mileage INTEGER, cost REAL DEFAULT 0,
            status TEXT DEFAULT 'Open', notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE)""")

        c.execute("""CREATE TABLE IF NOT EXISTS parts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            part_name TEXT, vehicle_id INTEGER, brand TEXT,
            part_number TEXT, quantity INTEGER DEFAULT 1,
            storage_location TEXT, cost REAL DEFAULT 0,
            purchased_from TEXT, purchase_date TEXT,
            used INTEGER DEFAULT 0, linked_record TEXT, notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL)""")

        c.execute("""CREATE TABLE IF NOT EXISTS fluids (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id INTEGER UNIQUE,
            oil_type TEXT, oil_capacity TEXT, trans_fluid TEXT,
            coolant_type TEXT, brake_fluid TEXT, ps_fluid TEXT,
            diff_fluid TEXT, spark_plug TEXT, tire_size TEXT,
            tire_pressure TEXT, battery_size TEXT, wiper_sizes TEXT, notes TEXT,
            FOREIGN KEY(vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE)""")

        c.execute("""CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id INTEGER, date TEXT, title TEXT, system TEXT,
            content TEXT, lessons_learned TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE)""")

        c.execute("""CREATE TABLE IF NOT EXISTS fuel_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id INTEGER, date TEXT, mileage INTEGER,
            gallons REAL, price_per_gallon REAL, total_cost REAL,
            station TEXT, notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE)""")

        self.conn.commit()

    def close(self):
        self.conn.close()

    # ---- Vehicles ----
    def get_vehicles(self):
        return self.conn.execute("SELECT * FROM vehicles ORDER BY year DESC, make, model").fetchall()

    def get_vehicle(self, vid):
        return self.conn.execute("SELECT * FROM vehicles WHERE id=?", (vid,)).fetchone()

    def add_vehicle(self, data):
        cols = ",".join(data.keys())
        ph   = ",".join(["?"]*len(data))
        self.conn.execute(f"INSERT INTO vehicles ({cols}) VALUES ({ph})", list(data.values()))
        self.conn.commit()

    def update_vehicle(self, vid, data):
        sets = ",".join([f"{k}=?" for k in data])
        self.conn.execute(f"UPDATE vehicles SET {sets} WHERE id=?", list(data.values())+[vid])
        self.conn.commit()

    def delete_vehicle(self, vid):
        self.conn.execute("DELETE FROM vehicles WHERE id=?", (vid,))
        self.conn.commit()

    # ---- Maintenance ----
    def _vname(self):
        return "v.year||' '||v.make||' '||v.model"

    def get_maintenance(self, vehicle_id=None, filters=None):
        q = f"SELECT m.*,{self._vname()} as vehicle_name FROM maintenance m JOIN vehicles v ON m.vehicle_id=v.id"
        w, p = [], []
        if vehicle_id: w.append("m.vehicle_id=?"); p.append(vehicle_id)
        if filters:
            if filters.get("category"): w.append("m.category=?"); p.append(filters["category"])
            if filters.get("keyword"):
                k=f"%{filters['keyword']}%"; w.append("(m.service LIKE ? OR m.parts LIKE ? OR m.notes LIKE ?)"); p+=[k,k,k]
        if w: q += " WHERE "+" AND ".join(w)
        q += " ORDER BY m.date DESC, m.id DESC"
        return self.conn.execute(q, p).fetchall()

    def add_maintenance(self, data):
        cols=",".join(data.keys()); ph=",".join(["?"]*len(data))
        self.conn.execute(f"INSERT INTO maintenance ({cols}) VALUES ({ph})", list(data.values()))
        self.conn.commit()

    def update_maintenance(self, mid, data):
        sets=",".join([f"{k}=?" for k in data])
        self.conn.execute(f"UPDATE maintenance SET {sets} WHERE id=?", list(data.values())+[mid])
        self.conn.commit()

    def delete_maintenance(self, mid):
        self.conn.execute("DELETE FROM maintenance WHERE id=?", (mid,)); self.conn.commit()

    # ---- Schedule ----
    def get_schedules(self, vehicle_id=None):
        q = f"SELECT s.*,{self._vname()} as vehicle_name FROM service_schedule s JOIN vehicles v ON s.vehicle_id=v.id"
        if vehicle_id: q += " WHERE s.vehicle_id=?"; return self.conn.execute(q,(vehicle_id,)).fetchall()
        return self.conn.execute(q).fetchall()

    def add_schedule(self, data):
        cols=",".join(data.keys()); ph=",".join(["?"]*len(data))
        self.conn.execute(f"INSERT INTO service_schedule ({cols}) VALUES ({ph})", list(data.values()))
        self.conn.commit()

    def update_schedule(self, sid, data):
        sets=",".join([f"{k}=?" for k in data])
        self.conn.execute(f"UPDATE service_schedule SET {sets} WHERE id=?", list(data.values())+[sid])
        self.conn.commit()

    def delete_schedule(self, sid):
        self.conn.execute("DELETE FROM service_schedule WHERE id=?", (sid,)); self.conn.commit()

    # ---- Modifications ----
    def get_modifications(self, vehicle_id=None, wishlist=False):
        q = f"SELECT m.*,{self._vname()} as vehicle_name FROM modifications m JOIN vehicles v ON m.vehicle_id=v.id"
        w,p=[],[]
        if vehicle_id: w.append("m.vehicle_id=?"); p.append(vehicle_id)
        if wishlist: w.append("m.status!='Installed'")
        else:        w.append("m.status='Installed'")
        if w: q += " WHERE "+" AND ".join(w)
        q += " ORDER BY m.date_installed DESC"
        return self.conn.execute(q, p).fetchall()

    def add_modification(self, data):
        cols=",".join(data.keys()); ph=",".join(["?"]*len(data))
        self.conn.execute(f"INSERT INTO modifications ({cols}) VALUES ({ph})", list(data.values()))
        self.conn.commit()

    def update_modification(self, mid, data):
        sets=",".join([f"{k}=?" for k in data])
        self.conn.execute(f"UPDATE modifications SET {sets} WHERE id=?", list(data.values())+[mid])
        self.conn.commit()

    def delete_modification(self, mid):
        self.conn.execute("DELETE FROM modifications WHERE id=?", (mid,)); self.conn.commit()

    # ---- Repairs ----
    def get_repairs(self, vehicle_id=None, filters=None):
        q = f"SELECT r.*,{self._vname()} as vehicle_name FROM repairs r JOIN vehicles v ON r.vehicle_id=v.id"
        w,p=[],[]
        if vehicle_id: w.append("r.vehicle_id=?"); p.append(vehicle_id)
        if filters:
            if filters.get("status"): w.append("r.status=?"); p.append(filters["status"])
            if filters.get("keyword"):
                k=f"%{filters['keyword']}%"; w.append("(r.issue_title LIKE ? OR r.symptoms LIKE ? OR r.trouble_codes LIKE ?)"); p+=[k,k,k]
        if w: q += " WHERE "+" AND ".join(w)
        q += " ORDER BY r.date_noticed DESC"
        return self.conn.execute(q, p).fetchall()

    def add_repair(self, data):
        cols=",".join(data.keys()); ph=",".join(["?"]*len(data))
        self.conn.execute(f"INSERT INTO repairs ({cols}) VALUES ({ph})", list(data.values()))
        self.conn.commit()

    def update_repair(self, rid, data):
        sets=",".join([f"{k}=?" for k in data])
        self.conn.execute(f"UPDATE repairs SET {sets} WHERE id=?", list(data.values())+[rid])
        self.conn.commit()

    def delete_repair(self, rid):
        self.conn.execute("DELETE FROM repairs WHERE id=?", (rid,)); self.conn.commit()

    # ---- Parts ----
    def get_parts(self, vehicle_id=None, used=None):
        q = f"SELECT p.*,{self._vname()} as vehicle_name FROM parts p LEFT JOIN vehicles v ON p.vehicle_id=v.id"
        w,p2=[],[]
        if vehicle_id is not None: w.append("p.vehicle_id=?"); p2.append(vehicle_id)
        if used is not None: w.append("p.used=?"); p2.append(1 if used else 0)
        if w: q += " WHERE "+" AND ".join(w)
        q += " ORDER BY p.part_name"
        return self.conn.execute(q, p2).fetchall()

    def add_part(self, data):
        cols=",".join(data.keys()); ph=",".join(["?"]*len(data))
        self.conn.execute(f"INSERT INTO parts ({cols}) VALUES ({ph})", list(data.values()))
        self.conn.commit()

    def update_part(self, pid, data):
        sets=",".join([f"{k}=?" for k in data])
        self.conn.execute(f"UPDATE parts SET {sets} WHERE id=?", list(data.values())+[pid])
        self.conn.commit()

    def delete_part(self, pid):
        self.conn.execute("DELETE FROM parts WHERE id=?", (pid,)); self.conn.commit()

    # ---- Fluids ----
    def get_fluids(self, vehicle_id):
        return self.conn.execute("SELECT * FROM fluids WHERE vehicle_id=?", (vehicle_id,)).fetchone()

    def save_fluids(self, vehicle_id, data):
        if self.get_fluids(vehicle_id):
            sets=",".join([f"{k}=?" for k in data])
            self.conn.execute(f"UPDATE fluids SET {sets} WHERE vehicle_id=?", list(data.values())+[vehicle_id])
        else:
            data2={"vehicle_id":vehicle_id,**data}
            cols=",".join(data2.keys()); ph=",".join(["?"]*len(data2))
            self.conn.execute(f"INSERT INTO fluids ({cols}) VALUES ({ph})", list(data2.values()))
        self.conn.commit()

    # ---- Notes ----
    def get_notes(self, vehicle_id=None, system=None):
        q = f"SELECT n.*,{self._vname()} as vehicle_name FROM notes n JOIN vehicles v ON n.vehicle_id=v.id"
        w,p=[],[]
        if vehicle_id: w.append("n.vehicle_id=?"); p.append(vehicle_id)
        if system:     w.append("n.system=?");     p.append(system)
        if w: q += " WHERE "+" AND ".join(w)
        q += " ORDER BY n.date DESC"
        return self.conn.execute(q, p).fetchall()

    def add_note(self, data):
        cols=",".join(data.keys()); ph=",".join(["?"]*len(data))
        self.conn.execute(f"INSERT INTO notes ({cols}) VALUES ({ph})", list(data.values()))
        self.conn.commit()

    def update_note(self, nid, data):
        sets=",".join([f"{k}=?" for k in data])
        self.conn.execute(f"UPDATE notes SET {sets} WHERE id=?", list(data.values())+[nid])
        self.conn.commit()

    def delete_note(self, nid):
        self.conn.execute("DELETE FROM notes WHERE id=?", (nid,)); self.conn.commit()

    # ---- Fuel ----
    def get_fuel_log(self, vehicle_id):
        return self.conn.execute(
            "SELECT * FROM fuel_log WHERE vehicle_id=? ORDER BY date DESC, mileage DESC",
            (vehicle_id,)).fetchall()

    def add_fuel(self, data):
        cols=",".join(data.keys()); ph=",".join(["?"]*len(data))
        self.conn.execute(f"INSERT INTO fuel_log ({cols}) VALUES ({ph})", list(data.values()))
        self.conn.commit()

    def delete_fuel(self, fid):
        self.conn.execute("DELETE FROM fuel_log WHERE id=?", (fid,)); self.conn.commit()

    # ---- Cost Summary ----
    def get_cost_summary(self, vehicle_id=None):
        if vehicle_id:
            p=(vehicle_id,)
            maint  = self.conn.execute("SELECT COALESCE(SUM(total_cost),0) FROM maintenance  WHERE vehicle_id=?",p).fetchone()[0]
            repair = self.conn.execute("SELECT COALESCE(SUM(cost),0)       FROM repairs       WHERE vehicle_id=?",p).fetchone()[0]
            mods   = self.conn.execute("SELECT COALESCE(SUM(cost),0)       FROM modifications WHERE vehicle_id=? AND status='Installed'",p).fetchone()[0]
            parts  = self.conn.execute("SELECT COALESCE(SUM(cost*quantity),0) FROM parts WHERE vehicle_id=?",p).fetchone()[0]
        else:
            maint  = self.conn.execute("SELECT COALESCE(SUM(total_cost),0)    FROM maintenance").fetchone()[0]
            repair = self.conn.execute("SELECT COALESCE(SUM(cost),0)           FROM repairs").fetchone()[0]
            mods   = self.conn.execute("SELECT COALESCE(SUM(cost),0)           FROM modifications WHERE status='Installed'").fetchone()[0]
            parts  = self.conn.execute("SELECT COALESCE(SUM(cost*quantity),0)  FROM parts").fetchone()[0]
        t = (maint or 0)+(repair or 0)+(mods or 0)+(parts or 0)
        return {"maintenance":maint or 0,"repair":repair or 0,"modifications":mods or 0,"parts":parts or 0,"total":t}

    # ---- Dashboard helpers ----
    def get_overdue_services(self, days_warning=30, miles_warning=500):
        schedules = self.get_schedules()
        today     = date.today()
        overdue, due_soon, upcoming = [], [], []
        for s in schedules:
            v = self.get_vehicle(s["vehicle_id"])
            cur_mi = (v["mileage"] or 0) if v else 0
            is_ov, is_ds = False, False
            if s["next_due_date"]:
                try:
                    diff = (date.fromisoformat(s["next_due_date"]) - today).days
                    if diff < 0: is_ov = True
                    elif diff <= days_warning: is_ds = True
                except: pass
            if s["next_due_mileage"] and cur_mi:
                diff_mi = s["next_due_mileage"] - cur_mi
                if diff_mi < 0: is_ov = True
                elif diff_mi <= miles_warning: is_ds = True
            item = {**dict(s), "current_mileage": cur_mi}
            if is_ov:        overdue.append(item)
            elif is_ds:      due_soon.append(item)
            else:            upcoming.append(item)
        return overdue, due_soon, upcoming

    def get_open_repairs(self, vehicle_id=None):
        q = f"SELECT r.*,{self._vname()} as vehicle_name FROM repairs r JOIN vehicles v ON r.vehicle_id=v.id WHERE r.status!='Repaired'"
        if vehicle_id: q += f" AND r.vehicle_id={vehicle_id}"
        return self.conn.execute(q).fetchall()

    def get_recent_maintenance(self, vehicle_id=None, limit=5):
        q = f"SELECT m.*,{self._vname()} as vehicle_name FROM maintenance m JOIN vehicles v ON m.vehicle_id=v.id"
        if vehicle_id: q += f" WHERE m.vehicle_id={vehicle_id}"
        q += f" ORDER BY m.date DESC LIMIT {limit}"
        return self.conn.execute(q).fetchall()

    # ---- Backup / Export ----
    def backup(self, dest):
        shutil.copy2(self.path, dest)

    def export_table_csv(self, table, dest):
        rows = self.conn.execute(f"SELECT * FROM {table}").fetchall()
        if not rows: return False
        with open(dest, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(rows[0].keys())
            for r in rows: w.writerow(list(r))
        return True


# ============================================================
# STYLED WIDGETS
# ============================================================

class SE(tk.Entry):
    """Styled Entry"""
    def __init__(self, parent, **kw):
        super().__init__(parent, bg=COLORS["entry_bg"], fg=COLORS["text_primary"],
                         insertbackground=COLORS["text_primary"],
                         relief="flat", bd=4, font=FONT_LABEL, **kw)

class SL(tk.Label):
    """Styled Label"""
    def __init__(self, parent, text="", font=None, fg=None, bg=None, **kw):
        super().__init__(parent, text=text,
                         font=font or FONT_LABEL,
                         fg=fg   or COLORS["text_primary"],
                         bg=bg   or COLORS["bg_medium"], **kw)

class ST(tk.Text):
    """Styled Text"""
    def __init__(self, parent, height=4, **kw):
        super().__init__(parent, bg=COLORS["entry_bg"], fg=COLORS["text_primary"],
                         insertbackground=COLORS["text_primary"],
                         relief="flat", bd=4, font=FONT_LABEL,
                         height=height, wrap="word", **kw)

class SC(ttk.Combobox):
    """Styled Combobox"""
    def __init__(self, parent, values=None, **kw):
        super().__init__(parent, values=values or [], font=FONT_LABEL, **kw)


class SB(tk.Button):
    """Styled Button"""
    def __init__(self, parent, text="", command=None, color=None, **kw):
        color = color or COLORS["btn_primary"]
        super().__init__(parent, text=text, command=command,
                         bg=color, fg=COLORS["text_primary"],
                         font=FONT_LABEL_BOLD, relief="flat", bd=0,
                         padx=12, pady=6, cursor="hand2",
                         activebackground=color,
                         activeforeground=COLORS["text_primary"], **kw)
        self._c = color
        self.bind("<Enter>", lambda e: self.config(bg=_lighten(color)))
        self.bind("<Leave>", lambda e: self.config(bg=color))


def _lighten(hex_color):
    try:
        r=min(255,int(hex_color[1:3],16)+30)
        g=min(255,int(hex_color[3:5],16)+30)
        b=min(255,int(hex_color[5:7],16)+30)
        return f"#{r:02x}{g:02x}{b:02x}"
    except: return hex_color


class ScrollFrame(tk.Frame):
    """Canvas-based scrollable frame."""
    def __init__(self, parent, bg=None, **kw):
        bg = bg or COLORS["bg_medium"]
        super().__init__(parent, bg=bg, **kw)
        c   = tk.Canvas(self, bg=bg, highlightthickness=0)
        vsb = ttk.Scrollbar(self, orient="vertical", command=c.yview)
        self.inner = tk.Frame(c, bg=bg)
        self.inner.bind("<Configure>", lambda e: c.configure(scrollregion=c.bbox("all")))
        c.create_window((0,0), window=self.inner, anchor="nw")
        c.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        c.pack(side="left", fill="both", expand=True)
        c.bind_all("<MouseWheel>", lambda e: c.yview_scroll(int(-1*(e.delta/120)),"units"))


class TreeFrame(ttk.Treeview):
    """Styled sortable treeview."""
    def __init__(self, parent, columns, headings, height=15, **kw):
        super().__init__(parent, columns=columns, show="headings", height=height, **kw)
        for col, head in zip(columns, headings):
            self.heading(col, text=head, command=lambda c=col: self._sort(c,False))
            self.column(col, anchor="w", width=120, minwidth=60)
        self.tag_configure("odd",    background=COLORS["table_bg"])
        self.tag_configure("even",   background=COLORS["table_alt"])
        self.tag_configure("danger", background="#3d1010")
        self.tag_configure("warn",   background="#3d2800")
        self.tag_configure("ok",     background="#0d2d1a")

    def _sort(self, col, rev):
        data = [(self.set(c,col),c) for c in self.get_children("")]
        data.sort(reverse=rev)
        for i,(v,c) in enumerate(data): self.move(c,"",i)
        self.heading(col, command=lambda: self._sort(col, not rev))

    def repopulate(self, rows_fn):
        """rows_fn should call insert() for each row after clearing."""
        for item in self.get_children(): self.delete(item)
        rows_fn()


def _lbl(parent, text, req=False, bg=None):
    bg = bg or COLORS["bg_dark"]
    t  = text+(" *" if req else "")
    return tk.Label(parent, text=t, font=FONT_LABEL_BOLD,
                    fg=COLORS["accent"] if req else COLORS["text_secondary"],
                    bg=bg, anchor="e")


def field(parent, label, wtype="entry", row=0, col=0,
          values=None, required=False, bg=None, height=3, colspan=1):
    """Place a label+widget in a 2-col grid pair. Returns widget."""
    bg = bg or COLORS["bg_dark"]
    _lbl(parent, label, required, bg).grid(row=row, column=col*2,
                                            padx=(15,5), pady=4, sticky="e")
    if   wtype == "entry":
        w = SE(parent)
    elif wtype == "combo":
        w = SC(parent, values=values or [])
        w.configure(state="readonly")
    elif wtype == "combo_e":
        w = SC(parent, values=values or [])
    elif wtype == "text":
        w = ST(parent, height=height)
    else:
        w = SE(parent)
    cs = colspan*2 - 1
    w.grid(row=row, column=col*2+1, padx=(0,15), pady=4, sticky="ew", columnspan=cs)
    parent.columnconfigure(col*2+1, weight=1)
    return w


def make_tree(parent, columns, headings, height=18):
    """Create a treeview with both scrollbars."""
    frame = tk.Frame(parent, bg=COLORS["bg_dark"])
    frame.pack(fill="both", expand=True, padx=10, pady=5)
    tree  = TreeFrame(frame, columns, headings, height=height)
    vsb   = ttk.Scrollbar(frame, orient="vertical",   command=tree.yview)
    hsb   = ttk.Scrollbar(frame, orient="horizontal",  command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    vsb.pack(side="right",  fill="y")
    hsb.pack(side="bottom", fill="x")
    tree.pack(fill="both",  expand=True)
    return tree


def v_map(db):
    """Return (map_dict, names_list) for vehicle combo boxes."""
    m, n = {}, []
    for v in db.get_vehicles():
        nm = f"{v['year']} {v['make']} {v['model']}"
        m[nm] = v["id"]; n.append(nm)
    return m, n


# ============================================================
# BASE PAGE
# ============================================================

class BasePage(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg=COLORS["bg_medium"])
        self.app = app
        self.db  = app.db
        self._build_ui()

    def _build_ui(self): pass
    def refresh(self):  pass

    def _header(self, title, sub=""):
        h = tk.Frame(self, bg=COLORS["bg_light"], pady=15)
        h.pack(fill="x")
        tk.Label(h, text=title, font=FONT_TITLE,
                 fg=COLORS["text_primary"], bg=COLORS["bg_light"]).pack(padx=20, anchor="w")
        if sub:
            tk.Label(h, text=sub, font=FONT_LABEL,
                     fg=COLORS["text_secondary"], bg=COLORS["bg_light"]).pack(padx=20, anchor="w")

    def _toolbar(self, parent=None):
        bar = tk.Frame(parent or self, bg=COLORS["sidebar"], pady=6, padx=10)
        bar.pack(fill="x")
        return bar

    def _no_selection(self):
        messagebox.showwarning("Select", "Please select a record first.")


# ============================================================
# DASHBOARD
# ============================================================

class DashboardPage(BasePage):
    def _build_ui(self):
        self._header("🏠 Dashboard", "Your garage at a glance")
        sf = ScrollFrame(self, bg=COLORS["bg_medium"])
        sf.pack(fill="both", expand=True)
        self._body = sf.inner

    def refresh(self):
        for w in self._body.winfo_children(): w.destroy()
        body = self._body

        # Quick actions
        tk.Label(body, text="Quick Actions", font=FONT_SUBTITLE,
                 fg=COLORS["text_primary"], bg=COLORS["bg_medium"]).pack(anchor="w", padx=20, pady=(15,5))
        qf = tk.Frame(body, bg=COLORS["bg_medium"]); qf.pack(fill="x", padx=20, pady=5)
        for lbl, pg, col in [
            ("➕ Maintenance","maintenance",COLORS["btn_primary"]),
            ("🔧 Repair",     "repairs",    COLORS["btn_secondary"]),
            ("⚡ Modification","modifications",COLORS["btn_success"]),
            ("📝 Note",       "notes",      "#1a6b8a"),
            ("📦 Part",       "parts",      "#5c5c1a"),
            ("📅 Schedule",   "schedule",   "#1a5c3c"),
        ]:
            SB(qf, lbl, lambda p=pg: self.app.navigate(p), col).pack(side="left", padx=4)

        # Stat cards
        vehicles = self.db.get_vehicles()
        costs    = self.db.get_cost_summary()
        overdue, due_soon, _ = self.db.get_overdue_services()
        open_r   = self.db.get_open_repairs()

        sf2 = tk.Frame(body, bg=COLORS["bg_medium"]); sf2.pack(fill="x", padx=20, pady=10)
        for val, lbl, col in [
            (str(len(vehicles)),        "🚗 Vehicles",    COLORS["info"]),
            (format_currency(costs["total"]), "💰 Total Spent", COLORS["warning"]),
            (str(len(overdue)),         "⚠️ Overdue",     COLORS["danger"]),
            (str(len(due_soon)),        "🔔 Due Soon",    COLORS["warning"]),
            (str(len(open_r)),          "🔧 Open Issues", COLORS["accent"]),
        ]:
            card = tk.Frame(sf2, bg=COLORS["bg_dark"], padx=22, pady=14)
            card.pack(side="left", padx=8)
            tk.Label(card, text=val, font=("Segoe UI",22,"bold"),
                     fg=col, bg=COLORS["bg_dark"]).pack()
            tk.Label(card, text=lbl, font=FONT_SMALL,
                     fg=COLORS["text_secondary"], bg=COLORS["bg_dark"]).pack()

        # Two-column detail area
        cols_f = tk.Frame(body, bg=COLORS["bg_medium"]); cols_f.pack(fill="both", padx=20, pady=10)
        cols_f.columnconfigure(0, weight=1); cols_f.columnconfigure(1, weight=1)

        L = tk.Frame(cols_f, bg=COLORS["bg_medium"])
        L.grid(row=0, column=0, sticky="nsew", padx=(0,10))
        R = tk.Frame(cols_f, bg=COLORS["bg_medium"])
        R.grid(row=0, column=1, sticky="nsew", padx=(10,0))

        def sec(parent, title):
            tk.Label(parent, text=title, font=FONT_LABEL_BOLD,
                     fg=COLORS["accent"], bg=COLORS["bg_medium"]).pack(anchor="w", pady=(10,2))
            f = tk.Frame(parent, bg=COLORS["bg_dark"], pady=8); f.pack(fill="x")
            return f

        # Overdue / due soon
        svc_f = sec(L, "⚠️ Overdue & Due Soon Services")
        shown = 0
        for s in overdue[:5]:
            self._svc_row(svc_f, s, "danger"); shown+=1
        for s in due_soon[:5]:
            self._svc_row(svc_f, s, "warn");   shown+=1
        if not shown:
            tk.Label(svc_f, text="✅ All services up to date!", font=FONT_LABEL,
                     fg=COLORS["success"], bg=COLORS["bg_dark"], pady=8).pack()

        # Open repairs
        rep_f = sec(L, "🔧 Open Issues")
        for r in open_r[:6]:
            row = tk.Frame(rep_f, bg=COLORS["bg_dark"]); row.pack(fill="x", padx=10, pady=2)
            tk.Label(row, text=f"• {r['vehicle_name']}: {r['issue_title']}",
                     font=FONT_LABEL, fg=COLORS["text_primary"],
                     bg=COLORS["bg_dark"], anchor="w").pack(side="left")
            tk.Label(row, text=f"[{r['status']}]", font=FONT_SMALL,
                     fg=COLORS["danger"] if r["status"]=="Open" else COLORS["warning"],
                     bg=COLORS["bg_dark"]).pack(side="right")
        if not open_r:
            tk.Label(rep_f, text="✅ No open issues!", font=FONT_LABEL,
                     fg=COLORS["success"], bg=COLORS["bg_dark"], pady=8).pack()

        # Recent maintenance
        mf = sec(R, "🔩 Recent Maintenance")
        for m in self.db.get_recent_maintenance(limit=6):
            row = tk.Frame(mf, bg=COLORS["bg_dark"]); row.pack(fill="x", padx=10, pady=2)
            tk.Label(row, text=f"{m['date']}: {m['vehicle_name']}",
                     font=FONT_SMALL, fg=COLORS["text_secondary"],
                     bg=COLORS["bg_dark"], anchor="w").pack(side="left")
            tk.Label(row, text=(m["service"] or "")[:35],
                     font=FONT_LABEL, fg=COLORS["text_primary"], bg=COLORS["bg_dark"]).pack(side="right")
        if not self.db.get_recent_maintenance():
            tk.Label(mf, text="No records yet.", font=FONT_LABEL,
                     fg=COLORS["text_muted"], bg=COLORS["bg_dark"], pady=8).pack()

        # Cost by vehicle
        cf = sec(R, "💰 Cost by Vehicle")
        for v in vehicles[:6]:
            c  = self.db.get_cost_summary(v["id"])
            nm = f"{v['year']} {v['make']} {v['model']}"
            row = tk.Frame(cf, bg=COLORS["bg_dark"]); row.pack(fill="x", padx=10, pady=2)
            tk.Label(row, text=f"• {nm}", font=FONT_LABEL,
                     fg=COLORS["text_primary"], bg=COLORS["bg_dark"], anchor="w").pack(side="left")
            tk.Label(row, text=format_currency(c["total"]), font=FONT_LABEL_BOLD,
                     fg=COLORS["warning"], bg=COLORS["bg_dark"]).pack(side="right")
        if not vehicles:
            tk.Label(cf, text="Add a vehicle to get started.", font=FONT_LABEL,
                     fg=COLORS["text_muted"], bg=COLORS["bg_dark"], pady=8).pack()

    def _svc_row(self, parent, s, tag):
        color = COLORS["danger"] if tag=="danger" else COLORS["warning"]
        icon  = "🔴" if tag=="danger" else "🟡"
        row   = tk.Frame(parent, bg=COLORS["bg_dark"]); row.pack(fill="x", padx=10, pady=2)
        tk.Label(row, text=f"{icon} {s['vehicle_name']}: {s['service_name']}",
                 font=FONT_LABEL, fg=color, bg=COLORS["bg_dark"], anchor="w").pack(side="left")
        info = s.get("next_due_date","") or ""
        if s.get("next_due_mileage"): info += f" / {format_mileage(s['next_due_mileage'])}"
        tk.Label(row, text=info, font=FONT_SMALL,
                 fg=COLORS["text_secondary"], bg=COLORS["bg_dark"]).pack(side="right")


# ============================================================
# VEHICLES
# ============================================================

class VehiclesPage(BasePage):
    def _build_ui(self):
        self._header("🚗 Vehicle Garage", "Manage your fleet")
        tb = self._toolbar()
        SB(tb,"➕ Add",    self._add,    COLORS["btn_primary"]).pack(side="left",padx=4)
        SB(tb,"✏️ Edit",   self._edit,   COLORS["btn_secondary"]).pack(side="left",padx=4)
        SB(tb,"🗑️ Delete", self._delete, COLORS["btn_danger"]).pack(side="left",padx=4)
        SB(tb,"⭐ Set Active", self._set_active, COLORS["btn_success"]).pack(side="left",padx=4)
        SB(tb,"📤 Export CSV", self._export, "#1a5c5c").pack(side="right",padx=4)
        self._active_lbl = tk.Label(tb, text="", font=FONT_LABEL,
                                    fg=COLORS["warning"], bg=COLORS["sidebar"])
        self._active_lbl.pack(side="right", padx=15)

        self.tree = make_tree(self,
            ["year","make","model","trim","color","mileage","engine","trans",
             "purchase_date","buy_price","plate","vin"],
            ["Year","Make","Model","Trim","Color","Mileage","Engine","Trans",
             "Purchased","Buy $","Plate","VIN"])
        self.tree.column("year",  width=55)
        self.tree.column("make",  width=90)
        self.tree.column("model", width=110)
        self.tree.column("mileage", width=90)
        self.tree.bind("<Double-1>", lambda e: self._edit())

    def refresh(self):
        self.tree.repopulate(self._fill)
        if self.app.selected_vehicle_id:
            v = self.db.get_vehicle(self.app.selected_vehicle_id)
            if v:
                self._active_lbl.config(
                    text=f"Active: {v['year']} {v['make']} {v['model']}",
                    fg=COLORS["success"])

    def _fill(self):
        for i, v in enumerate(self.db.get_vehicles()):
            tag = "ok" if self.app.selected_vehicle_id==v["id"] else ("even" if i%2==0 else "odd")
            self.tree.insert("","end", iid=str(v["id"]), tags=(tag,), values=(
                v["year"], v["make"], v["model"], v["trim"] or "",
                v["color"] or "", format_mileage(v["mileage"]),
                v["engine"] or "", v["transmission"] or "",
                v["purchase_date"] or "", format_currency(v["purchase_price"]),
                v["license_plate"] or "", v["vin"] or ""))

    def _sel(self):
        s = self.tree.selection()
        if not s: self._no_selection(); return None
        return int(s[0])

    def _add(self):
        d = VehicleDialog(self, self.app); self.wait_window(d); self.refresh()

    def _edit(self):
        vid = self._sel()
        if not vid: return
        d = VehicleDialog(self, self.app, self.db.get_vehicle(vid))
        self.wait_window(d); self.refresh()

    def _delete(self):
        vid = self._sel()
        if not vid: return
        v   = self.db.get_vehicle(vid)
        nm  = f"{v['year']} {v['make']} {v['model']}"
        if messagebox.askyesno("Delete",
            f"Delete {nm}?\n\nAll associated records will also be deleted.\nThis cannot be undone!"):
            self.db.delete_vehicle(vid)
            if self.app.selected_vehicle_id == vid:
                self.app.selected_vehicle_id = None
            self.app.update_vehicle_selector()
            self.refresh()

    def _set_active(self):
        vid = self._sel()
        if not vid: return
        self.app.selected_vehicle_id = vid
        self.app.update_vehicle_selector()
        self.refresh()

    def _export(self):
        p = filedialog.asksaveasfilename(defaultextension=".csv",
            filetypes=[("CSV","*.csv")], initialfile="vehicles.csv")
        if p: self.db.export_table_csv("vehicles", p); messagebox.showinfo("Done",f"Saved to {p}")


class VehicleDialog(tk.Toplevel):
    def __init__(self, parent, app, vehicle=None):
        super().__init__(parent)
        self.app=app; self.db=app.db; self.vehicle=vehicle
        self.title("Edit Vehicle" if vehicle else "Add Vehicle")
        self.configure(bg=COLORS["bg_dark"])
        self.geometry("820x680"); self.resizable(True,True); self.grab_set()

        tk.Label(self, text="Vehicle Information", font=FONT_SUBTITLE,
                 fg=COLORS["text_primary"], bg=COLORS["bg_light"], pady=10).pack(fill="x")

        sf = ScrollFrame(self, bg=COLORS["bg_dark"]); sf.pack(fill="both", expand=True)
        b  = sf.inner; b.configure(bg=COLORS["bg_dark"])
        b.columnconfigure(1,weight=1); b.columnconfigure(3,weight=1)

        self.fy   = field(b,"Year *",  row=0,col=0,required=True,  bg=COLORS["bg_dark"])
        self.fmk  = field(b,"Make *",  row=0,col=1,required=True,  bg=COLORS["bg_dark"])
        self.fmd  = field(b,"Model *", row=1,col=0,required=True,  bg=COLORS["bg_dark"])
        self.ftr  = field(b,"Trim",    row=1,col=1,bg=COLORS["bg_dark"])
        self.fvin = field(b,"VIN",     row=2,col=0,bg=COLORS["bg_dark"])
        self.fpl  = field(b,"License Plate", row=2,col=1,bg=COLORS["bg_dark"])
        self.fmi  = field(b,"Current Mileage",row=3,col=0,bg=COLORS["bg_dark"])
        self.fcol = field(b,"Color",   row=3,col=1,bg=COLORS["bg_dark"])
        self.feng = field(b,"Engine",  row=4,col=0,bg=COLORS["bg_dark"])
        self.ftra = field(b,"Transmission",row=4,col=1,bg=COLORS["bg_dark"])
        self.fpd  = field(b,"Purchase Date (YYYY-MM-DD)",row=5,col=0,bg=COLORS["bg_dark"])
        self.fpp  = field(b,"Purchase Price ($)",row=5,col=1,bg=COLORS["bg_dark"])
        self.fcv  = field(b,"Current Value ($)", row=6,col=0,bg=COLORS["bg_dark"])
        self.fre  = field(b,"Registration Expiry",row=6,col=1,bg=COLORS["bg_dark"])
        self.fic  = field(b,"Insurance Company",row=7,col=0,bg=COLORS["bg_dark"])
        self.fip  = field(b,"Policy Number",row=7,col=1,bg=COLORS["bg_dark"])
        self.fie  = field(b,"Insurance Expiry",row=8,col=0,bg=COLORS["bg_dark"])
        _lbl(b,"Notes",bg=COLORS["bg_dark"]).grid(row=9,column=0,padx=(15,5),pady=4,sticky="ne")
        self.fn = ST(b, height=4)
        self.fn.grid(row=9,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")

        if vehicle: self._populate(vehicle)

        bf = tk.Frame(self,bg=COLORS["bg_medium"],pady=10); bf.pack(fill="x",side="bottom")
        SB(bf,"Cancel",self.destroy,COLORS["btn_danger"]).pack(side="right",padx=10)
        SB(bf,"💾 Save",self._save,COLORS["btn_success"]).pack(side="right",padx=5)

    def _populate(self, v):
        pairs=[(self.fy,"year"),(self.fmk,"make"),(self.fmd,"model"),(self.ftr,"trim"),
               (self.fvin,"vin"),(self.fpl,"license_plate"),(self.fmi,"mileage"),
               (self.fcol,"color"),(self.feng,"engine"),(self.ftra,"transmission"),
               (self.fpd,"purchase_date"),(self.fpp,"purchase_price"),(self.fcv,"current_value"),
               (self.fre,"registration_expiry"),(self.fic,"insurance_company"),
               (self.fip,"insurance_policy"),(self.fie,"insurance_expiry")]
        for w,k in pairs:
            if v[k] is not None: w.insert(0,str(v[k]))
        if v["notes"]: self.fn.insert("1.0",v["notes"])

    def _save(self):
        y=self.fy.get().strip(); mk=self.fmk.get().strip(); md=self.fmd.get().strip()
        if not all([y,mk,md]):
            messagebox.showerror("Required","Year, Make, and Model are required."); return
        mi=self.fmi.get().strip()
        if mi and not mi.lstrip("-").isdigit():
            messagebox.showerror("Invalid","Mileage must be a whole number."); return
        for f,lbl in [(self.fpd,"Purchase Date"),(self.fre,"Registration Expiry"),(self.fie,"Insurance Expiry")]:
            v=f.get().strip()
            if v and not validate_date(v):
                messagebox.showerror("Invalid Date",f"{lbl} must be YYYY-MM-DD."); return
        data={"year":y,"make":mk,"model":md,"trim":self.ftr.get().strip(),
              "vin":self.fvin.get().strip(),"license_plate":self.fpl.get().strip(),
              "mileage":int(mi) if mi else 0,"color":self.fcol.get().strip(),
              "engine":self.feng.get().strip(),"transmission":self.ftra.get().strip(),
              "purchase_date":self.fpd.get().strip(),"purchase_price":float(self.fpp.get().strip() or 0),
              "current_value":float(self.fcv.get().strip() or 0),
              "registration_expiry":self.fre.get().strip(),
              "insurance_company":self.fic.get().strip(),"insurance_policy":self.fip.get().strip(),
              "insurance_expiry":self.fie.get().strip(),"notes":self.fn.get("1.0","end").strip()}
        if self.vehicle: self.db.update_vehicle(self.vehicle["id"],data)
        else:
            self.db.add_vehicle(data)
            self.app.update_vehicle_selector()
        self.destroy()


# ============================================================
# MAINTENANCE
# ============================================================

class MaintenancePage(BasePage):
    def _build_ui(self):
        self._header("🔩 Maintenance Log","Track all service records")

        # Filter bar
        fb = tk.Frame(self,bg=COLORS["bg_dark"],pady=8,padx=10); fb.pack(fill="x")
        tk.Label(fb,text="Vehicle:",font=FONT_LABEL,fg=COLORS["text_secondary"],bg=COLORS["bg_dark"]).pack(side="left",padx=(5,2))
        self._vm, vn = v_map(self.db)
        self._vm = {"All Vehicles":None, **self._vm}; vn=["All Vehicles"]+vn
        self.v_cb = SC(fb,values=vn,width=25); self.v_cb.set("All Vehicles")
        self.v_cb.pack(side="left",padx=5)
        self.v_cb.bind("<<ComboboxSelected>>",lambda e:self.refresh())

        tk.Label(fb,text="Category:",font=FONT_LABEL,fg=COLORS["text_secondary"],bg=COLORS["bg_dark"]).pack(side="left",padx=(10,2))
        self.cat_cb = SC(fb,values=["All"]+MAINTENANCE_CATEGORIES,width=16); self.cat_cb.set("All")
        self.cat_cb.pack(side="left",padx=5)
        self.cat_cb.bind("<<ComboboxSelected>>",lambda e:self.refresh())

        tk.Label(fb,text="Search:",font=FONT_LABEL,fg=COLORS["text_secondary"],bg=COLORS["bg_dark"]).pack(side="left",padx=(10,2))
        self.kw = tk.StringVar()
        SE(fb,textvariable=self.kw,width=22).pack(side="left",padx=5)
        SB(fb,"🔍",self.refresh,COLORS["bg_light"]).pack(side="left")
        SB(fb,"Clear",self._clear,COLORS["text_muted"]).pack(side="left",padx=4)

        tb = self._toolbar()
        SB(tb,"➕ Add",   self._add,   COLORS["btn_primary"]).pack(side="left",padx=4)
        SB(tb,"✏️ Edit",  self._edit,  COLORS["btn_secondary"]).pack(side="left",padx=4)
        SB(tb,"🗑️ Delete",self._delete,COLORS["btn_danger"]).pack(side="left",padx=4)
        SB(tb,"📤 Export CSV",self._export,"#1a5c5c").pack(side="right",padx=4)
        self._sum_lbl = tk.Label(tb,text="",font=FONT_LABEL,fg=COLORS["warning"],bg=COLORS["sidebar"])
        self._sum_lbl.pack(side="right",padx=15)

        self.tree = make_tree(self,
            ["date","vehicle","category","service","mileage","labor_by",
             "parts_cost","labor_cost","total","notes"],
            ["Date","Vehicle","Category","Service","Mileage","Done By",
             "Parts $","Labor $","Total $","Notes"])
        self.tree.column("service",width=180)
        self.tree.column("vehicle",width=130)
        self.tree.bind("<Double-1>",lambda e:self._edit())

    def _reload_vm(self):
        m,n = v_map(self.db)
        self._vm = {"All Vehicles":None,**m}
        self.v_cb["values"] = ["All Vehicles"]+n
        if self.v_cb.get() not in self._vm: self.v_cb.set("All Vehicles")

    def refresh(self):
        self._reload_vm()
        vid = self._vm.get(self.v_cb.get())
        cat = self.cat_cb.get()
        kw  = self.kw.get().strip()
        filters = {}
        if cat and cat!="All": filters["category"]=cat
        if kw: filters["keyword"]=kw
        records = self.db.get_maintenance(vid, filters or None)
        total   = 0

        def fill():
            nonlocal total; total=0
            for i,r in enumerate(records):
                tag="even" if i%2==0 else "odd"
                total += r["total_cost"] or 0
                self.tree.insert("","end",iid=str(r["id"]),tags=(tag,),values=(
                    r["date"] or "",r["vehicle_name"],r["category"] or "",
                    r["service"] or "",format_mileage(r["mileage"]),
                    r["labor_by"] or "",format_currency(r["cost_parts"]),
                    format_currency(r["cost_labor"]),format_currency(r["total_cost"]),
                    (r["notes"] or "")[:50]))
        self.tree.repopulate(fill)
        self._sum_lbl.config(text=f"{len(records)} records | Total: {format_currency(total)}")

    def _clear(self):
        self.v_cb.set("All Vehicles"); self.cat_cb.set("All"); self.kw.set(""); self.refresh()

    def _sel(self):
        s=self.tree.selection()
        if not s: self._no_selection(); return None
        return int(s[0])

    def _add(self):
        if not self.db.get_vehicles():
            messagebox.showwarning("No Vehicles","Add a vehicle first."); return
        d=MaintenanceDialog(self,self.app); self.wait_window(d); self.refresh()

    def _edit(self):
        mid=self._sel()
        if not mid: return
        r=self.db.conn.execute("SELECT * FROM maintenance WHERE id=?",(mid,)).fetchone()
        d=MaintenanceDialog(self,self.app,r); self.wait_window(d); self.refresh()

    def _delete(self):
        mid=self._sel()
        if not mid: return
        if messagebox.askyesno("Delete","Delete this maintenance record?"):
            self.db.delete_maintenance(mid); self.refresh()

    def _export(self):
        p=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="maintenance.csv")
        if p: self.db.export_table_csv("maintenance",p); messagebox.showinfo("Done",f"Saved to {p}")


class MaintenanceDialog(tk.Toplevel):
    def __init__(self, parent, app, record=None):
        super().__init__(parent)
        self.app=app; self.db=app.db; self.rec=record
        self.title("Edit Maintenance" if record else "Add Maintenance")
        self.configure(bg=COLORS["bg_dark"])
        self.geometry("800x680"); self.resizable(True,True); self.grab_set()

        tk.Label(self,text="Maintenance Record",font=FONT_SUBTITLE,
                 fg=COLORS["text_primary"],bg=COLORS["bg_light"],pady=10).pack(fill="x")
        sf=ScrollFrame(self,bg=COLORS["bg_dark"]); sf.pack(fill="both",expand=True)
        b=sf.inner; b.configure(bg=COLORS["bg_dark"])
        b.columnconfigure(1,weight=1); b.columnconfigure(3,weight=1)

        self._vm,vn = v_map(self.db)
        _lbl(b,"Vehicle *",True,COLORS["bg_dark"]).grid(row=0,column=0,padx=(15,5),pady=4,sticky="e")
        self.fv=SC(b,values=vn); self.fv.configure(state="readonly")
        self.fv.grid(row=0,column=1,padx=(0,15),pady=4,sticky="ew")

        _lbl(b,"Date *",True,COLORS["bg_dark"]).grid(row=0,column=2,padx=(15,5),pady=4,sticky="e")
        self.fd=SE(b); self.fd.insert(0,today_str())
        self.fd.grid(row=0,column=3,padx=(0,15),pady=4,sticky="ew")

        self.fmi  = field(b,"Mileage",                     row=1,col=0,bg=COLORS["bg_dark"])
        self.fcat = field(b,"Category","combo",             row=1,col=1,values=MAINTENANCE_CATEGORIES,bg=COLORS["bg_dark"])
        _lbl(b,"Service *",True,COLORS["bg_dark"]).grid(row=2,column=0,padx=(15,5),pady=4,sticky="e")
        self.fsvc=SE(b); self.fsvc.grid(row=2,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")

        self.fpts = field(b,"Parts Used",             row=3,col=0,bg=COLORS["bg_dark"])
        self.ffl  = field(b,"Fluids Used",            row=3,col=1,bg=COLORS["bg_dark"])
        self.flb  = field(b,"Done By","combo",         row=4,col=0,values=LABOR_BY,bg=COLORS["bg_dark"])
        self.frc  = field(b,"Receipt / Invoice Ref",  row=4,col=1,bg=COLORS["bg_dark"])
        self.fcp  = field(b,"Parts Cost ($)",          row=5,col=0,bg=COLORS["bg_dark"])
        self.fcl  = field(b,"Labor Cost ($)",          row=5,col=1,bg=COLORS["bg_dark"])

        _lbl(b,"Total Cost ($)",bg=COLORS["bg_dark"]).grid(row=6,column=0,padx=(15,5),pady=4,sticky="e")
        self.fto=SE(b); self.fto.insert(0,"0.00")
        self.fto.grid(row=6,column=1,padx=(0,15),pady=4,sticky="ew")
        SB(b,"⚡ Auto-calc Total",self._calc,COLORS["btn_secondary"]).grid(row=6,column=2,columnspan=2,padx=15,pady=4)

        _lbl(b,"Notes",bg=COLORS["bg_dark"]).grid(row=7,column=0,padx=(15,5),pady=4,sticky="ne")
        self.fn=ST(b,height=4); self.fn.grid(row=7,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")

        if record: self._populate(record)
        elif app.selected_vehicle_id:
            v=self.db.get_vehicle(app.selected_vehicle_id)
            if v: self.fv.set(f"{v['year']} {v['make']} {v['model']}")

        bf=tk.Frame(self,bg=COLORS["bg_medium"],pady=10); bf.pack(fill="x",side="bottom")
        SB(bf,"Cancel",self.destroy,COLORS["btn_danger"]).pack(side="right",padx=10)
        SB(bf,"💾 Save",self._save,COLORS["btn_success"]).pack(side="right",padx=5)

    def _populate(self,r):
        v=self.db.get_vehicle(r["vehicle_id"])
        if v: self.fv.set(f"{v['year']} {v['make']} {v['model']}")
        self.fd.delete(0,"end"); self.fd.insert(0,r["date"] or today_str())
        self.fsvc.delete(0,"end"); self.fsvc.insert(0,r["service"] or "")
        for w,k in [(self.fmi,"mileage"),(self.fpts,"parts"),(self.ffl,"fluids"),
                    (self.frc,"receipt_ref"),(self.fcp,"cost_parts"),(self.fcl,"cost_labor"),(self.fto,"total_cost")]:
            if r[k] is not None: w.delete(0,"end"); w.insert(0,str(r[k]))
        if r["category"]: self.fcat.set(r["category"])
        if r["labor_by"]: self.flb.set(r["labor_by"])
        if r["notes"]: self.fn.insert("1.0",r["notes"])

    def _calc(self):
        try:
            p=float(self.fcp.get() or 0); l=float(self.fcl.get() or 0)
            self.fto.delete(0,"end"); self.fto.insert(0,f"{p+l:.2f}")
        except: pass

    def _save(self):
        vn=self.fv.get()
        if not vn or vn not in self._vm:
            messagebox.showerror("Required","Please select a vehicle."); return
        svc=self.fsvc.get().strip()
        if not svc:
            messagebox.showerror("Required","Service performed is required."); return
        dt=self.fd.get().strip()
        if not validate_date(dt):
            messagebox.showerror("Invalid","Date must be YYYY-MM-DD."); return
        mi=self.fmi.get().strip()
        data={"vehicle_id":self._vm[vn],"date":dt,
              "mileage":int(mi) if mi.isdigit() else 0,
              "category":self.fcat.get(),"service":svc,
              "parts":self.fpts.get().strip(),"fluids":self.ffl.get().strip(),
              "labor_by":self.flb.get(),"receipt_ref":self.frc.get().strip(),
              "cost_parts":float(self.fcp.get().strip() or 0),
              "cost_labor":float(self.fcl.get().strip() or 0),
              "total_cost":float(self.fto.get().strip() or 0),
              "notes":self.fn.get("1.0","end").strip()}
        if self.rec: self.db.update_maintenance(self.rec["id"],data)
        else:        self.db.add_maintenance(data)
        self.destroy()


# ============================================================
# SERVICE SCHEDULE
# ============================================================

class SchedulePage(BasePage):
    def _build_ui(self):
        self._header("📅 Service Schedule","Reminders & recurring maintenance")
        tb=self._toolbar()
        SB(tb,"➕ Add",     self._add,        COLORS["btn_primary"]).pack(side="left",padx=4)
        SB(tb,"✏️ Edit",    self._edit,       COLORS["btn_secondary"]).pack(side="left",padx=4)
        SB(tb,"🗑️ Delete",  self._delete,     COLORS["btn_danger"]).pack(side="left",padx=4)
        SB(tb,"✅ Mark Done",self._mark_done,  COLORS["btn_success"]).pack(side="left",padx=4)

        self._filt=tk.StringVar(value="All")
        for val in ["All","Overdue","Due Soon","Upcoming"]:
            tk.Radiobutton(tb,text=val,variable=self._filt,value=val,
                           command=self.refresh,bg=COLORS["sidebar"],
                           fg=COLORS["text_primary"],selectcolor=COLORS["entry_bg"],
                           activebackground=COLORS["sidebar"],
                           activeforeground=COLORS["text_primary"]).pack(side="left",padx=4)

        self._sum_f=tk.Frame(self,bg=COLORS["bg_dark"],pady=6,padx=15); self._sum_f.pack(fill="x")

        self.tree=make_tree(self,
            ["vehicle","service","int_mi","int_day","last_date","last_mi",
             "next_date","next_mi","priority","status"],
            ["Vehicle","Service","Mi Interval","Day Interval","Last Done","Last Mi",
             "Next Date","Next Mi","Priority","Status"])
        self.tree.column("vehicle",width=140)
        self.tree.column("service",width=160)
        self.tree.bind("<Double-1>",lambda e:self._edit())

    def refresh(self):
        for w in self._sum_f.winfo_children(): w.destroy()
        overdue,due_soon,upcoming=self.db.get_overdue_services()
        for lbl,items,col in [("🔴 Overdue",overdue,COLORS["danger"]),
                               ("🟡 Due Soon",due_soon,COLORS["warning"]),
                               ("🟢 Upcoming",upcoming,COLORS["success"])]:
            tk.Label(self._sum_f,text=f"{lbl}: {len(items)}",font=FONT_LABEL_BOLD,
                     fg=col,bg=COLORS["bg_dark"]).pack(side="left",padx=20)

        filt=self._filt.get()
        if   filt=="Overdue":  show=[(s,"danger") for s in overdue]
        elif filt=="Due Soon": show=[(s,"warn")   for s in due_soon]
        elif filt=="Upcoming": show=[(s,"ok")     for s in upcoming]
        else:                  show=[(s,"danger") for s in overdue]+[(s,"warn") for s in due_soon]+[(s,"ok") for s in upcoming]

        stat_map={"danger":"OVERDUE","warn":"Due Soon","ok":"OK"}
        def fill():
            for s,tag in show:
                self.tree.insert("","end",iid=str(s["id"]),tags=(tag,),values=(
                    s["vehicle_name"],s["service_name"],
                    format_mileage(s["interval_miles"]) if s["interval_miles"] else "",
                    f"{s['interval_days']} days" if s["interval_days"] else "",
                    s["last_done_date"] or "Never",
                    format_mileage(s["last_done_mileage"]) if s["last_done_mileage"] else "",
                    s["next_due_date"] or "",
                    format_mileage(s["next_due_mileage"]) if s["next_due_mileage"] else "",
                    s["priority"] or "",stat_map[tag]))
        self.tree.repopulate(fill)

    def _sel(self):
        s=self.tree.selection()
        if not s: self._no_selection(); return None
        return int(s[0])

    def _add(self):
        if not self.db.get_vehicles(): messagebox.showwarning("No Vehicles","Add a vehicle first."); return
        d=ScheduleDialog(self,self.app); self.wait_window(d); self.refresh()

    def _edit(self):
        sid=self._sel()
        if not sid: return
        r=self.db.conn.execute("SELECT * FROM service_schedule WHERE id=?",(sid,)).fetchone()
        d=ScheduleDialog(self,self.app,r); self.wait_window(d); self.refresh()

    def _delete(self):
        sid=self._sel()
        if not sid: return
        if messagebox.askyesno("Delete","Delete this schedule item?"):
            self.db.delete_schedule(sid); self.refresh()

    def _mark_done(self):
        sid=self._sel()
        if not sid: return
        r=self.db.conn.execute("SELECT * FROM service_schedule WHERE id=?",(sid,)).fetchone()
        v=self.db.get_vehicle(r["vehicle_id"])
        mi=simpledialog.askstring("Mark Done",
            f"Current mileage for {v['year']} {v['make']} {v['model']}?",
            initialvalue=str(v["mileage"] or ""))
        if mi is None: return
        today=today_str(); mi_int=int(mi.strip()) if mi.strip().isdigit() else None
        nd=None; nm=None
        if r["interval_days"]:
            nd=(date.today()+timedelta(days=r["interval_days"])).isoformat()
        if r["interval_miles"] and mi_int:
            nm=mi_int+r["interval_miles"]
        self.db.update_schedule(sid,{"last_done_date":today,"last_done_mileage":mi_int,
                                     "next_due_date":nd,"next_due_mileage":nm})
        if mi_int and v and mi_int>(v["mileage"] or 0):
            self.db.update_vehicle(v["id"],{"mileage":mi_int})
        self.refresh()
        messagebox.showinfo("Updated",
            f"Marked done!\nNext due: {nd or 'N/A'} / {format_mileage(nm) if nm else 'N/A'}")


class ScheduleDialog(tk.Toplevel):
    def __init__(self,parent,app,record=None):
        super().__init__(parent)
        self.app=app; self.db=app.db; self.rec=record
        self.title("Edit Schedule" if record else "Add Schedule")
        self.configure(bg=COLORS["bg_dark"]); self.geometry("700x560")
        self.resizable(True,True); self.grab_set()
        tk.Label(self,text="Service Schedule",font=FONT_SUBTITLE,
                 fg=COLORS["text_primary"],bg=COLORS["bg_light"],pady=10).pack(fill="x")
        sf=ScrollFrame(self,bg=COLORS["bg_dark"]); sf.pack(fill="both",expand=True)
        b=sf.inner; b.configure(bg=COLORS["bg_dark"])
        b.columnconfigure(1,weight=1); b.columnconfigure(3,weight=1)

        self._vm,vn=v_map(self.db)
        _lbl(b,"Vehicle *",True,COLORS["bg_dark"]).grid(row=0,column=0,padx=(15,5),pady=4,sticky="e")
        self.fv=SC(b,values=vn); self.fv.configure(state="readonly")
        self.fv.grid(row=0,column=1,padx=(0,15),pady=4,sticky="ew")

        self.fn  =field(b,"Service Name *",row=0,col=1,required=True,bg=COLORS["bg_dark"])
        self.fim =field(b,"Interval (Miles)",row=1,col=0,bg=COLORS["bg_dark"])
        self.fid =field(b,"Interval (Days)", row=1,col=1,bg=COLORS["bg_dark"])
        self.fld =field(b,"Last Done Date",  row=2,col=0,bg=COLORS["bg_dark"])
        self.flm =field(b,"Last Done Mileage",row=2,col=1,bg=COLORS["bg_dark"])
        self.fnd =field(b,"Next Due Date",   row=3,col=0,bg=COLORS["bg_dark"])
        self.fnm =field(b,"Next Due Mileage",row=3,col=1,bg=COLORS["bg_dark"])
        self.fp  =field(b,"Priority","combo",row=4,col=0,values=PRIORITIES,bg=COLORS["bg_dark"])
        self.fp.set("Medium")
        SB(b,"⚡ Auto-calculate Next",self._auto,COLORS["btn_secondary"]).grid(row=4,column=2,columnspan=2,padx=15)
        _lbl(b,"Notes",bg=COLORS["bg_dark"]).grid(row=5,column=0,padx=(15,5),pady=4,sticky="ne")
        self.fno=ST(b,height=3); self.fno.grid(row=5,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")

        if record: self._populate(record)
        elif app.selected_vehicle_id:
            v=self.db.get_vehicle(app.selected_vehicle_id)
            if v: self.fv.set(f"{v['year']} {v['make']} {v['model']}")

        bf=tk.Frame(self,bg=COLORS["bg_medium"],pady=10); bf.pack(fill="x",side="bottom")
        SB(bf,"Cancel",self.destroy,COLORS["btn_danger"]).pack(side="right",padx=10)
        SB(bf,"💾 Save",self._save,COLORS["btn_success"]).pack(side="right",padx=5)

    def _populate(self,r):
        v=self.db.get_vehicle(r["vehicle_id"])
        if v: self.fv.set(f"{v['year']} {v['make']} {v['model']}")
        self.fn.delete(0,"end"); self.fn.insert(0,r["service_name"] or "")
        for w,k in [(self.fim,"interval_miles"),(self.fid,"interval_days"),
                    (self.fld,"last_done_date"),(self.flm,"last_done_mileage"),
                    (self.fnd,"next_due_date"),(self.fnm,"next_due_mileage")]:
            if r[k]: w.delete(0,"end"); w.insert(0,str(r[k]))
        if r["priority"]: self.fp.set(r["priority"])
        if r["notes"]: self.fno.insert("1.0",r["notes"])

    def _auto(self):
        try:
            ld=self.fld.get().strip(); lm=self.flm.get().strip()
            id_=self.fid.get().strip(); im=self.fim.get().strip()
            if ld and id_:
                nd=(date.fromisoformat(ld)+timedelta(days=int(id_))).isoformat()
                self.fnd.delete(0,"end"); self.fnd.insert(0,nd)
            if lm and im:
                nm=int(lm)+int(im)
                self.fnm.delete(0,"end"); self.fnm.insert(0,str(nm))
        except Exception as e: messagebox.showerror("Error",str(e))

    def _save(self):
        vn=self.fv.get(); nm=self.fn.get().strip()
        if not vn or vn not in self._vm: messagebox.showerror("Required","Select a vehicle."); return
        if not nm: messagebox.showerror("Required","Service name required."); return
        def _i(w): return int(w.get().strip()) if w.get().strip().isdigit() else None
        data={"vehicle_id":self._vm[vn],"service_name":nm,
              "interval_miles":_i(self.fim),"interval_days":_i(self.fid),
              "last_done_date":self.fld.get().strip() or None,"last_done_mileage":_i(self.flm),
              "next_due_date":self.fnd.get().strip() or None,"next_due_mileage":_i(self.fnm),
              "priority":self.fp.get(),"notes":self.fno.get("1.0","end").strip()}
        if self.rec: self.db.update_schedule(self.rec["id"],data)
        else:        self.db.add_schedule(data)
        self.destroy()


# ============================================================
# MODIFICATIONS
# ============================================================

class ModificationsPage(BasePage):
    def _build_ui(self):
        self._header("⚡ Modification Tracker","Upgrades & wishlist")
        tf=tk.Frame(self,bg=COLORS["bg_dark"],pady=6,padx=10); tf.pack(fill="x")
        self._tab=tk.StringVar(value="installed")
        for lbl,val in [("Installed","installed"),("Wishlist / Planned","wishlist")]:
            tk.Radiobutton(tf,text=lbl,variable=self._tab,value=val,
                           command=self.refresh,bg=COLORS["bg_dark"],
                           fg=COLORS["text_primary"],selectcolor=COLORS["entry_bg"],
                           font=FONT_LABEL_BOLD,activebackground=COLORS["bg_dark"],
                           activeforeground=COLORS["text_primary"]).pack(side="left",padx=12)

        tb=self._toolbar()
        SB(tb,"➕ Add",         self._add,          COLORS["btn_primary"]).pack(side="left",padx=4)
        SB(tb,"✏️ Edit",        self._edit,         COLORS["btn_secondary"]).pack(side="left",padx=4)
        SB(tb,"🗑️ Delete",      self._delete,       COLORS["btn_danger"]).pack(side="left",padx=4)
        SB(tb,"✅ Mark Installed",self._mark_installed,COLORS["btn_success"]).pack(side="left",padx=4)
        SB(tb,"📤 Export CSV",  self._export,        "#1a5c5c").pack(side="right",padx=4)
        self._sum=tk.Label(tb,text="",font=FONT_LABEL,fg=COLORS["warning"],bg=COLORS["sidebar"])
        self._sum.pack(side="right",padx=15)

        self.tree=make_tree(self,
            ["vehicle","date","name","category","brand","cost",
             "col6","col7","col8","notes"],
            ["Vehicle","Date","Mod Name","Category","Brand","Cost",
             "Installed By","Tune?","Warranty?","Notes"])
        self.tree.column("name",width=160); self.tree.column("notes",width=200)
        self.tree.bind("<Double-1>",lambda e:self._edit())

    def refresh(self):
        wl=self._tab.get()=="wishlist"
        recs=self.db.get_modifications(wishlist=wl)
        total=0
        def fill():
            nonlocal total; total=0
            for i,r in enumerate(recs):
                tag="even" if i%2==0 else "odd"
                cost=r["estimated_cost"] if wl else r["cost"]
                total+=cost or 0
                if wl:
                    vals=(r["vehicle_name"],r["date_installed"] or "",r["name"],
                          r["category"] or "",r["brand"] or "",format_currency(r["estimated_cost"]),
                          r["status"] or "",r["priority"] or "","–",(r["notes"] or "")[:50])
                else:
                    vals=(r["vehicle_name"],r["date_installed"] or "",r["name"],
                          r["category"] or "",r["brand"] or "",format_currency(r["cost"]),
                          r["installed_by"] or "",r["tune_required"] or "No",
                          r["warranty_affected"] or "No",(r["notes"] or "")[:50])
                self.tree.insert("","end",iid=str(r["id"]),tags=(tag,),values=vals)
        self.tree.repopulate(fill)
        self._sum.config(text=f"{len(recs)} records | Total: {format_currency(total)}")

    def _sel(self):
        s=self.tree.selection()
        if not s: self._no_selection(); return None
        return int(s[0])

    def _add(self):
        if not self.db.get_vehicles(): messagebox.showwarning("No Vehicles","Add a vehicle first."); return
        wl=self._tab.get()=="wishlist"
        d=ModificationDialog(self,self.app,wishlist=wl); self.wait_window(d); self.refresh()

    def _edit(self):
        mid=self._sel()
        if not mid: return
        r=self.db.conn.execute("SELECT * FROM modifications WHERE id=?",(mid,)).fetchone()
        wl=self._tab.get()=="wishlist"
        d=ModificationDialog(self,self.app,r,wishlist=wl); self.wait_window(d); self.refresh()

    def _delete(self):
        mid=self._sel()
        if not mid: return
        if messagebox.askyesno("Delete","Delete this modification?"):
            self.db.delete_modification(mid); self.refresh()

    def _mark_installed(self):
        mid=self._sel()
        if not mid: return
        self.db.update_modification(mid,{"status":"Installed"}); self.refresh()

    def _export(self):
        p=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="modifications.csv")
        if p: self.db.export_table_csv("modifications",p); messagebox.showinfo("Done",f"Saved to {p}")


class ModificationDialog(tk.Toplevel):
    def __init__(self,parent,app,record=None,wishlist=False):
        super().__init__(parent)
        self.app=app; self.db=app.db; self.rec=record; self.wl=wishlist
        self.title("Edit Modification" if record else "Add Modification")
        self.configure(bg=COLORS["bg_dark"]); self.geometry("800x720")
        self.resizable(True,True); self.grab_set()
        tk.Label(self,text="Modification Record",font=FONT_SUBTITLE,
                 fg=COLORS["text_primary"],bg=COLORS["bg_light"],pady=10).pack(fill="x")
        sf=ScrollFrame(self,bg=COLORS["bg_dark"]); sf.pack(fill="both",expand=True)
        b=sf.inner; b.configure(bg=COLORS["bg_dark"])
        b.columnconfigure(1,weight=1); b.columnconfigure(3,weight=1)

        self._vm,vn=v_map(self.db)
        _lbl(b,"Vehicle *",True,COLORS["bg_dark"]).grid(row=0,column=0,padx=(15,5),pady=4,sticky="e")
        self.fv=SC(b,values=vn); self.fv.configure(state="readonly")
        self.fv.grid(row=0,column=1,padx=(0,15),pady=4,sticky="ew")
        self.fname=field(b,"Mod Name *",row=0,col=1,required=True,bg=COLORS["bg_dark"])
        self.fcat =field(b,"Category","combo",row=1,col=0,values=MOD_CATEGORIES,bg=COLORS["bg_dark"])
        self.fbrnd=field(b,"Brand",row=1,col=1,bg=COLORS["bg_dark"])
        self.fpn  =field(b,"Part Number",row=2,col=0,bg=COLORS["bg_dark"])

        if not wishlist:
            self.fdate=field(b,"Date Installed",row=2,col=1,bg=COLORS["bg_dark"])
            self.fmi  =field(b,"Mileage Installed",row=3,col=0,bg=COLORS["bg_dark"])
            self.fcost=field(b,"Cost ($)",row=3,col=1,bg=COLORS["bg_dark"])
            self.fib  =field(b,"Installed By","combo",row=4,col=0,values=LABOR_BY,bg=COLORS["bg_dark"])
            self.ftun =field(b,"Tune Required","combo",row=4,col=1,values=["No","Yes"],bg=COLORS["bg_dark"])
            self.fwar =field(b,"Warranty Affected","combo",row=5,col=0,values=["No","Yes"],bg=COLORS["bg_dark"])
            self.fsup =field(b,"Supporting Mods",row=5,col=1,bg=COLORS["bg_dark"])
            _lbl(b,"Before Notes",bg=COLORS["bg_dark"]).grid(row=6,column=0,padx=(15,5),pady=4,sticky="ne")
            self.fbef=ST(b,height=3); self.fbef.grid(row=6,column=1,padx=(0,15),pady=4,sticky="ew")
            _lbl(b,"After Notes",bg=COLORS["bg_dark"]).grid(row=6,column=2,padx=(15,5),pady=4,sticky="ne")
            self.faft=ST(b,height=3); self.faft.grid(row=6,column=3,padx=(0,15),pady=4,sticky="ew")
            _lbl(b,"Notes",bg=COLORS["bg_dark"]).grid(row=7,column=0,padx=(15,5),pady=4,sticky="ne")
            self.fno=ST(b,height=3); self.fno.grid(row=7,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")
        else:
            self.fst  =field(b,"Status","combo",row=2,col=1,values=MOD_STATUSES,bg=COLORS["bg_dark"])
            self.fst.set("Idea")
            self.fpri =field(b,"Priority","combo",row=3,col=0,values=PRIORITIES,bg=COLORS["bg_dark"])
            self.fest =field(b,"Est. Cost ($)",row=3,col=1,bg=COLORS["bg_dark"])
            _lbl(b,"Needed Parts",bg=COLORS["bg_dark"]).grid(row=4,column=0,padx=(15,5),pady=4,sticky="ne")
            self.fned=ST(b,height=3); self.fned.grid(row=4,column=1,padx=(0,15),pady=4,sticky="ew")
            _lbl(b,"Notes",bg=COLORS["bg_dark"]).grid(row=5,column=0,padx=(15,5),pady=4,sticky="ne")
            self.fno=ST(b,height=3); self.fno.grid(row=5,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")

        if record: self._populate(record)
        elif app.selected_vehicle_id:
            v=self.db.get_vehicle(app.selected_vehicle_id)
            if v: self.fv.set(f"{v['year']} {v['make']} {v['model']}")

        bf=tk.Frame(self,bg=COLORS["bg_medium"],pady=10); bf.pack(fill="x",side="bottom")
        SB(bf,"Cancel",self.destroy,COLORS["btn_danger"]).pack(side="right",padx=10)
        SB(bf,"💾 Save",self._save,COLORS["btn_success"]).pack(side="right",padx=5)

    def _populate(self,r):
        v=self.db.get_vehicle(r["vehicle_id"])
        if v: self.fv.set(f"{v['year']} {v['make']} {v['model']}")
        self.fname.delete(0,"end"); self.fname.insert(0,r["name"] or "")
        if r["category"]: self.fcat.set(r["category"])
        for w,k in [(self.fbrnd,"brand"),(self.fpn,"part_number")]:
            if r[k]: w.delete(0,"end"); w.insert(0,r[k])
        if not self.wl:
            for w,k in [(self.fdate,"date_installed"),(self.fmi,"mileage_installed"),
                        (self.fcost,"cost"),(self.fsup,"supporting_mods")]:
                if r[k] is not None: w.delete(0,"end"); w.insert(0,str(r[k]))
            if r["installed_by"]: self.fib.set(r["installed_by"])
            if r["tune_required"]: self.ftun.set(r["tune_required"])
            if r["warranty_affected"]: self.fwar.set(r["warranty_affected"])
            if r["before_notes"]: self.fbef.insert("1.0",r["before_notes"])
            if r["after_notes"]:  self.faft.insert("1.0",r["after_notes"])
        else:
            if r["status"]:   self.fst.set(r["status"])
            if r["priority"]: self.fpri.set(r["priority"])
            if r["estimated_cost"]: self.fest.delete(0,"end"); self.fest.insert(0,str(r["estimated_cost"]))
            if r["needed_parts"]: self.fned.insert("1.0",r["needed_parts"])
        if r["notes"]: self.fno.insert("1.0",r["notes"])

    def _save(self):
        vn=self.fv.get(); nm=self.fname.get().strip()
        if not vn or vn not in self._vm: messagebox.showerror("Required","Select a vehicle."); return
        if not nm: messagebox.showerror("Required","Mod name required."); return
        if not self.wl:
            mi=self.fmi.get().strip()
            data={"vehicle_id":self._vm[vn],"name":nm,"category":self.fcat.get(),
                  "brand":self.fbrnd.get().strip(),"part_number":self.fpn.get().strip(),
                  "date_installed":self.fdate.get().strip() or None,
                  "mileage_installed":int(mi) if mi.isdigit() else None,
                  "cost":float(self.fcost.get().strip() or 0),
                  "installed_by":self.fib.get(),"tune_required":self.ftun.get(),
                  "warranty_affected":self.fwar.get(),
                  "before_notes":self.fbef.get("1.0","end").strip(),
                  "after_notes":self.faft.get("1.0","end").strip(),
                  "supporting_mods":self.fsup.get().strip(),
                  "notes":self.fno.get("1.0","end").strip(),"status":"Installed"}
        else:
            data={"vehicle_id":self._vm[vn],"name":nm,"category":self.fcat.get(),
                  "brand":self.fbrnd.get().strip(),"part_number":self.fpn.get().strip(),
                  "status":self.fst.get(),"priority":self.fpri.get(),
                  "estimated_cost":float(self.fest.get().strip() or 0),
                  "needed_parts":self.fned.get("1.0","end").strip(),
                  "notes":self.fno.get("1.0","end").strip()}
        if self.rec: self.db.update_modification(self.rec["id"],data)
        else:        self.db.add_modification(data)
        self.destroy()


# ============================================================
# REPAIRS
# ============================================================

class RepairsPage(BasePage):
    def _build_ui(self):
        self._header("🔧 Repair Tracker","Track problems & fixes")
        fb=tk.Frame(self,bg=COLORS["bg_dark"],pady=8,padx=10); fb.pack(fill="x")
        tk.Label(fb,text="Status:",font=FONT_LABEL,fg=COLORS["text_secondary"],bg=COLORS["bg_dark"]).pack(side="left",padx=(5,2))
        self.st_cb=SC(fb,values=["All"]+REPAIR_STATUSES,width=18); self.st_cb.set("All")
        self.st_cb.pack(side="left",padx=5)
        self.st_cb.bind("<<ComboboxSelected>>",lambda e:self.refresh())
        tk.Label(fb,text="Search:",font=FONT_LABEL,fg=COLORS["text_secondary"],bg=COLORS["bg_dark"]).pack(side="left",padx=(10,2))
        self.kw=tk.StringVar()
        SE(fb,textvariable=self.kw,width=25).pack(side="left",padx=5)
        SB(fb,"🔍 Search",self.refresh,COLORS["bg_light"]).pack(side="left")

        tb=self._toolbar()
        SB(tb,"➕ Add Issue",    self._add,          COLORS["btn_primary"]).pack(side="left",padx=4)
        SB(tb,"✏️ Edit",         self._edit,         COLORS["btn_secondary"]).pack(side="left",padx=4)
        SB(tb,"🗑️ Delete",       self._delete,       COLORS["btn_danger"]).pack(side="left",padx=4)
        SB(tb,"✅ Mark Repaired", self._mark_repaired,COLORS["btn_success"]).pack(side="left",padx=4)
        SB(tb,"📤 Export CSV",   self._export,        "#1a5c5c").pack(side="right",padx=4)

        self.tree=make_tree(self,
            ["vehicle","date","title","status","symptoms","codes","cost","fixed","notes"],
            ["Vehicle","Noticed","Issue","Status","Symptoms","Codes","Cost","Fixed","Notes"])
        self.tree.column("title",width=170); self.tree.column("symptoms",width=200)
        self.tree.bind("<Double-1>",lambda e:self._edit())

    def refresh(self):
        st=self.st_cb.get(); kw=self.kw.get().strip()
        filters={}
        if st and st!="All": filters["status"]=st
        if kw: filters["keyword"]=kw
        recs=self.db.get_repairs(filters=filters or None)
        def fill():
            for i,r in enumerate(recs):
                if r["status"]=="Open":                            tag="danger"
                elif r["status"] in ("Diagnosing","Waiting on Parts"): tag="warn"
                elif r["status"]=="Repaired":                      tag="ok"
                else: tag="even" if i%2==0 else "odd"
                self.tree.insert("","end",iid=str(r["id"]),tags=(tag,),values=(
                    r["vehicle_name"],r["date_noticed"] or "",r["issue_title"],
                    r["status"],(r["symptoms"] or "")[:60],
                    r["trouble_codes"] or "",format_currency(r["cost"]),
                    r["fixed_date"] or "",(r["notes"] or "")[:40]))
        self.tree.repopulate(fill)

    def _sel(self):
        s=self.tree.selection()
        if not s: self._no_selection(); return None
        return int(s[0])

    def _add(self):
        if not self.db.get_vehicles(): messagebox.showwarning("No Vehicles","Add a vehicle first."); return
        d=RepairDialog(self,self.app); self.wait_window(d); self.refresh()

    def _edit(self):
        rid=self._sel()
        if not rid: return
        r=self.db.conn.execute("SELECT * FROM repairs WHERE id=?",(rid,)).fetchone()
        d=RepairDialog(self,self.app,r); self.wait_window(d); self.refresh()

    def _delete(self):
        rid=self._sel()
        if not rid: return
        if messagebox.askyesno("Delete","Delete this repair record?"):
            self.db.delete_repair(rid); self.refresh()

    def _mark_repaired(self):
        rid=self._sel()
        if not rid: return
        self.db.update_repair(rid,{"status":"Repaired","fixed_date":today_str()}); self.refresh()

    def _export(self):
        p=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="repairs.csv")
        if p: self.db.export_table_csv("repairs",p); messagebox.showinfo("Done",f"Saved to {p}")


class RepairDialog(tk.Toplevel):
    def __init__(self,parent,app,record=None):
        super().__init__(parent)
        self.app=app; self.db=app.db; self.rec=record
        self.title("Edit Issue" if record else "Add Issue")
        self.configure(bg=COLORS["bg_dark"]); self.geometry("800x760")
        self.resizable(True,True); self.grab_set()
        tk.Label(self,text="Repair / Issue Record",font=FONT_SUBTITLE,
                 fg=COLORS["text_primary"],bg=COLORS["bg_light"],pady=10).pack(fill="x")
        sf=ScrollFrame(self,bg=COLORS["bg_dark"]); sf.pack(fill="both",expand=True)
        b=sf.inner; b.configure(bg=COLORS["bg_dark"])
        b.columnconfigure(1,weight=1); b.columnconfigure(3,weight=1)

        self._vm,vn=v_map(self.db)
        _lbl(b,"Vehicle *",True,COLORS["bg_dark"]).grid(row=0,column=0,padx=(15,5),pady=4,sticky="e")
        self.fv=SC(b,values=vn); self.fv.configure(state="readonly")
        self.fv.grid(row=0,column=1,padx=(0,15),pady=4,sticky="ew")
        self.ftit=field(b,"Issue Title *",row=0,col=1,required=True,bg=COLORS["bg_dark"])
        self.fdn =field(b,"Date Noticed",row=1,col=0,bg=COLORS["bg_dark"])
        self.fdn.insert(0,today_str())
        self.fmn =field(b,"Mileage Noticed",row=1,col=1,bg=COLORS["bg_dark"])
        self.fst =field(b,"Status","combo",row=2,col=0,values=REPAIR_STATUSES,bg=COLORS["bg_dark"])
        self.fst.set("Open")
        self.fco =field(b,"Total Cost ($)",row=2,col=1,bg=COLORS["bg_dark"])
        _lbl(b,"Symptoms",bg=COLORS["bg_dark"]).grid(row=3,column=0,padx=(15,5),pady=4,sticky="ne")
        self.fsym=ST(b,height=3); self.fsym.grid(row=3,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")
        self.fcd =field(b,"Trouble Codes",row=4,col=0,bg=COLORS["bg_dark"])
        self.fpr =field(b,"Parts Replaced",row=4,col=1,bg=COLORS["bg_dark"])
        _lbl(b,"Diagnosis Notes",bg=COLORS["bg_dark"]).grid(row=5,column=0,padx=(15,5),pady=4,sticky="ne")
        self.fdi=ST(b,height=3); self.fdi.grid(row=5,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")
        _lbl(b,"Repair Steps",bg=COLORS["bg_dark"]).grid(row=6,column=0,padx=(15,5),pady=4,sticky="ne")
        self.frs=ST(b,height=3); self.frs.grid(row=6,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")
        self.ffd =field(b,"Fixed Date",row=7,col=0,bg=COLORS["bg_dark"])
        self.ffm =field(b,"Fixed Mileage",row=7,col=1,bg=COLORS["bg_dark"])
        _lbl(b,"Notes",bg=COLORS["bg_dark"]).grid(row=8,column=0,padx=(15,5),pady=4,sticky="ne")
        self.fno=ST(b,height=3); self.fno.grid(row=8,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")

        if record: self._populate(record)
        elif app.selected_vehicle_id:
            v=self.db.get_vehicle(app.selected_vehicle_id)
            if v: self.fv.set(f"{v['year']} {v['make']} {v['model']}")

        bf=tk.Frame(self,bg=COLORS["bg_medium"],pady=10); bf.pack(fill="x",side="bottom")
        SB(bf,"Cancel",self.destroy,COLORS["btn_danger"]).pack(side="right",padx=10)
        SB(bf,"💾 Save",self._save,COLORS["btn_success"]).pack(side="right",padx=5)

    def _populate(self,r):
        v=self.db.get_vehicle(r["vehicle_id"])
        if v: self.fv.set(f"{v['year']} {v['make']} {v['model']}")
        self.ftit.delete(0,"end"); self.ftit.insert(0,r["issue_title"] or "")
        for w,k in [(self.fdn,"date_noticed"),(self.fmn,"mileage_noticed"),(self.fco,"cost"),
                    (self.fcd,"trouble_codes"),(self.fpr,"parts_replaced"),
                    (self.ffd,"fixed_date"),(self.ffm,"fixed_mileage")]:
            if r[k] is not None: w.delete(0,"end"); w.insert(0,str(r[k]))
        if r["status"]: self.fst.set(r["status"])
        for w,k in [(self.fsym,"symptoms"),(self.fdi,"diagnosis_notes"),(self.frs,"repair_steps"),(self.fno,"notes")]:
            if r[k]: w.insert("1.0",r[k])

    def _save(self):
        vn=self.fv.get(); tit=self.ftit.get().strip()
        if not vn or vn not in self._vm: messagebox.showerror("Required","Select a vehicle."); return
        if not tit: messagebox.showerror("Required","Issue title required."); return
        mn=self.fmn.get().strip(); fm=self.ffm.get().strip()
        data={"vehicle_id":self._vm[vn],"issue_title":tit,
              "date_noticed":self.fdn.get().strip() or None,
              "mileage_noticed":int(mn) if mn.isdigit() else None,
              "symptoms":self.fsym.get("1.0","end").strip(),
              "trouble_codes":self.fcd.get().strip(),"parts_replaced":self.fpr.get().strip(),
              "diagnosis_notes":self.fdi.get("1.0","end").strip(),
              "repair_steps":self.frs.get("1.0","end").strip(),
              "fixed_date":self.ffd.get().strip() or None,
              "fixed_mileage":int(fm) if fm.isdigit() else None,
              "cost":float(self.fco.get().strip() or 0),
              "status":self.fst.get(),"notes":self.fno.get("1.0","end").strip()}
        if self.rec: self.db.update_repair(self.rec["id"],data)
        else:        self.db.add_repair(data)
        self.destroy()


# ============================================================
# PARTS
# ============================================================

class PartsPage(BasePage):
    def _build_ui(self):
        self._header("📦 Parts Inventory","Track parts on hand")
        fb=tk.Frame(self,bg=COLORS["bg_dark"],pady=8,padx=10); fb.pack(fill="x")
        self.show_used=tk.BooleanVar(value=False)
        tk.Checkbutton(fb,text="Show Used Parts",variable=self.show_used,command=self.refresh,
                       bg=COLORS["bg_dark"],fg=COLORS["text_primary"],
                       selectcolor=COLORS["entry_bg"],activebackground=COLORS["bg_dark"],
                       activeforeground=COLORS["text_primary"]).pack(side="left",padx=10)
        tk.Label(fb,text="Search:",font=FONT_LABEL,fg=COLORS["text_secondary"],bg=COLORS["bg_dark"]).pack(side="left",padx=(10,2))
        self.kw=tk.StringVar()
        SE(fb,textvariable=self.kw,width=25).pack(side="left",padx=5)
        SB(fb,"🔍",self.refresh,COLORS["bg_light"]).pack(side="left")

        tb=self._toolbar()
        SB(tb,"➕ Add Part",  self._add,       COLORS["btn_primary"]).pack(side="left",padx=4)
        SB(tb,"✏️ Edit",      self._edit,      COLORS["btn_secondary"]).pack(side="left",padx=4)
        SB(tb,"🗑️ Delete",    self._delete,    COLORS["btn_danger"]).pack(side="left",padx=4)
        SB(tb,"✅ Mark Used",  self._mark_used, COLORS["btn_success"]).pack(side="left",padx=4)
        SB(tb,"📤 Export CSV",self._export,     "#1a5c5c").pack(side="right",padx=4)
        self._sum=tk.Label(tb,text="",font=FONT_LABEL,fg=COLORS["warning"],bg=COLORS["sidebar"])
        self._sum.pack(side="right",padx=15)

        self.tree=make_tree(self,
            ["name","vehicle","brand","part_num","qty","location",
             "cost","from_","date","used","notes"],
            ["Part Name","Vehicle","Brand","Part #","Qty","Location",
             "Cost","From","Date","Status","Notes"])
        self.tree.column("name",width=160)
        self.tree.bind("<Double-1>",lambda e:self._edit())

    def refresh(self):
        used_f=None if self.show_used.get() else False
        recs=self.db.get_parts(used=used_f)
        kw=self.kw.get().strip().lower()
        if kw:
            recs=[r for r in recs if
                  kw in (r["part_name"] or "").lower() or
                  kw in (r["brand"] or "").lower() or
                  kw in (r["part_number"] or "").lower() or
                  kw in (r["notes"] or "").lower()]
        total=0
        def fill():
            nonlocal total; total=0
            for i,r in enumerate(recs):
                tag="ok" if r["used"] else ("even" if i%2==0 else "odd")
                total+=(r["cost"] or 0)*(r["quantity"] or 1)
                self.tree.insert("","end",iid=str(r["id"]),tags=(tag,),values=(
                    r["part_name"],r["vehicle_name"] or "Any",r["brand"] or "",
                    r["part_number"] or "",r["quantity"] or 1,
                    r["storage_location"] or "",format_currency(r["cost"]),
                    r["purchased_from"] or "",r["purchase_date"] or "",
                    "✅ Used" if r["used"] else "On Hand",(r["notes"] or "")[:40]))
        self.tree.repopulate(fill)
        self._sum.config(text=f"{len(recs)} parts | Value: {format_currency(total)}")

    def _sel(self):
        s=self.tree.selection()
        if not s: self._no_selection(); return None
        return int(s[0])

    def _add(self):
        d=PartDialog(self,self.app); self.wait_window(d); self.refresh()

    def _edit(self):
        pid=self._sel()
        if not pid: return
        r=self.db.conn.execute("SELECT * FROM parts WHERE id=?",(pid,)).fetchone()
        d=PartDialog(self,self.app,r); self.wait_window(d); self.refresh()

    def _delete(self):
        pid=self._sel()
        if not pid: return
        if messagebox.askyesno("Delete","Delete this part?"):
            self.db.delete_part(pid); self.refresh()

    def _mark_used(self):
        pid=self._sel()
        if not pid: return
        self.db.update_part(pid,{"used":1}); self.refresh()

    def _export(self):
        p=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="parts.csv")
        if p: self.db.export_table_csv("parts",p); messagebox.showinfo("Done",f"Saved to {p}")


class PartDialog(tk.Toplevel):
    def __init__(self,parent,app,record=None):
        super().__init__(parent)
        self.app=app; self.db=app.db; self.rec=record
        self.title("Edit Part" if record else "Add Part")
        self.configure(bg=COLORS["bg_dark"]); self.geometry("700x560")
        self.resizable(True,True); self.grab_set()
        tk.Label(self,text="Parts Inventory",font=FONT_SUBTITLE,
                 fg=COLORS["text_primary"],bg=COLORS["bg_light"],pady=10).pack(fill="x")
        sf=ScrollFrame(self,bg=COLORS["bg_dark"]); sf.pack(fill="both",expand=True)
        b=sf.inner; b.configure(bg=COLORS["bg_dark"])
        b.columnconfigure(1,weight=1); b.columnconfigure(3,weight=1)

        m,vn=v_map(self.db)
        self._vm={"Any Vehicle":None,**m}; vn=["Any Vehicle"]+vn
        _lbl(b,"Part Name *",True,COLORS["bg_dark"]).grid(row=0,column=0,padx=(15,5),pady=4,sticky="e")
        self.fn=SE(b); self.fn.grid(row=0,column=1,padx=(0,15),pady=4,sticky="ew")
        _lbl(b,"Vehicle",bg=COLORS["bg_dark"]).grid(row=0,column=2,padx=(15,5),pady=4,sticky="e")
        self.fv=SC(b,values=vn); self.fv.set("Any Vehicle"); self.fv.configure(state="readonly")
        self.fv.grid(row=0,column=3,padx=(0,15),pady=4,sticky="ew")
        self.fbrnd=field(b,"Brand",row=1,col=0,bg=COLORS["bg_dark"])
        self.fpn  =field(b,"Part Number",row=1,col=1,bg=COLORS["bg_dark"])
        self.fqty =field(b,"Quantity",row=2,col=0,bg=COLORS["bg_dark"])
        self.fqty.insert(0,"1")
        self.floc =field(b,"Storage Location",row=2,col=1,bg=COLORS["bg_dark"])
        self.fcst =field(b,"Cost ($)",row=3,col=0,bg=COLORS["bg_dark"])
        self.ffr  =field(b,"Purchased From",row=3,col=1,bg=COLORS["bg_dark"])
        self.fdt  =field(b,"Purchase Date",row=4,col=0,bg=COLORS["bg_dark"])
        self.fdt.insert(0,today_str())
        self.flnk =field(b,"Linked Record",row=4,col=1,bg=COLORS["bg_dark"])
        _lbl(b,"Notes",bg=COLORS["bg_dark"]).grid(row=5,column=0,padx=(15,5),pady=4,sticky="ne")
        self.fno=ST(b,height=3); self.fno.grid(row=5,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")

        if record: self._populate(record)

        bf=tk.Frame(self,bg=COLORS["bg_medium"],pady=10); bf.pack(fill="x",side="bottom")
        SB(bf,"Cancel",self.destroy,COLORS["btn_danger"]).pack(side="right",padx=10)
        SB(bf,"💾 Save",self._save,COLORS["btn_success"]).pack(side="right",padx=5)

    def _populate(self,r):
        self.fn.delete(0,"end"); self.fn.insert(0,r["part_name"] or "")
        if r["vehicle_id"]:
            v=self.db.get_vehicle(r["vehicle_id"])
            if v: self.fv.set(f"{v['year']} {v['make']} {v['model']}")
        for w,k in [(self.fbrnd,"brand"),(self.fpn,"part_number"),(self.fqty,"quantity"),
                    (self.floc,"storage_location"),(self.fcst,"cost"),(self.ffr,"purchased_from"),
                    (self.fdt,"purchase_date"),(self.flnk,"linked_record")]:
            if r[k] is not None: w.delete(0,"end"); w.insert(0,str(r[k]))
        if r["notes"]: self.fno.insert("1.0",r["notes"])

    def _save(self):
        nm=self.fn.get().strip()
        if not nm: messagebox.showerror("Required","Part name required."); return
        vn=self.fv.get(); vid=self._vm.get(vn)
        qty=self.fqty.get().strip()
        data={"part_name":nm,"vehicle_id":vid,"brand":self.fbrnd.get().strip(),
              "part_number":self.fpn.get().strip(),
              "quantity":int(qty) if qty.isdigit() else 1,
              "storage_location":self.floc.get().strip(),
              "cost":float(self.fcst.get().strip() or 0),
              "purchased_from":self.ffr.get().strip(),
              "purchase_date":self.fdt.get().strip() or None,
              "linked_record":self.flnk.get().strip(),
              "notes":self.fno.get("1.0","end").strip()}
        if self.rec: self.db.update_part(self.rec["id"],data)
        else:        self.db.add_part(data)
        self.destroy()


# ============================================================
# FLUIDS & SPECS
# ============================================================

class FluidsPage(BasePage):
    def _build_ui(self):
        self._header("🧪 Fluids & Specs","Fluid types & sizes for each vehicle")
        sb=tk.Frame(self,bg=COLORS["bg_dark"],pady=8,padx=15); sb.pack(fill="x")
        tk.Label(sb,text="Select Vehicle:",font=FONT_LABEL_BOLD,
                 fg=COLORS["text_primary"],bg=COLORS["bg_dark"]).pack(side="left",padx=5)
        self._vm={}
        self.vcb=SC(sb,width=30); self.vcb.pack(side="left",padx=10)
        self.vcb.bind("<<ComboboxSelected>>",lambda e:self._load())
        SB(sb,"💾 Save Specs",self._save,COLORS["btn_success"]).pack(side="left",padx=10)

        sf=ScrollFrame(self,bg=COLORS["bg_medium"]); sf.pack(fill="both",expand=True)
        self._body=sf.inner; self._body.configure(bg=COLORS["bg_medium"])
        self._widgets={}
        self._build_form()
        self._load_vehicles()

    def _build_form(self):
        for w in self._body.winfo_children(): w.destroy()
        self._body.columnconfigure(1,weight=1); self._body.columnconfigure(3,weight=1)
        specs=[
            ("Engine Oil Type","oil_type",0,0),("Oil Capacity","oil_capacity",0,1),
            ("Transmission Fluid","trans_fluid",1,0),("Coolant Type","coolant_type",1,1),
            ("Brake Fluid","brake_fluid",2,0),("Power Steering Fluid","ps_fluid",2,1),
            ("Differential Fluid","diff_fluid",3,0),("Spark Plug Type/Gap","spark_plug",3,1),
            ("Tire Size","tire_size",4,0),("Tire Pressure (PSI)","tire_pressure",4,1),
            ("Battery Size","battery_size",5,0),("Wiper Blade Sizes","wiper_sizes",5,1),
        ]
        for lbl,key,row,col in specs:
            _lbl(self._body,lbl,bg=COLORS["bg_medium"]).grid(row=row,column=col*2,padx=(15,5),pady=5,sticky="e")
            w=SE(self._body)
            w.grid(row=row,column=col*2+1,padx=(0,15),pady=5,sticky="ew")
            self._widgets[key]=w
        _lbl(self._body,"Additional Notes",bg=COLORS["bg_medium"]).grid(row=6,column=0,padx=(15,5),pady=5,sticky="ne")
        self._notes=ST(self._body,height=5)
        self._notes.grid(row=6,column=1,columnspan=3,padx=(0,15),pady=5,sticky="ew")

    def _load_vehicles(self):
        self._vm,names=v_map(self.db)
        self.vcb["values"]=names
        if self.app.selected_vehicle_id:
            v=self.db.get_vehicle(self.app.selected_vehicle_id)
            if v:
                self.vcb.set(f"{v['year']} {v['make']} {v['model']}"); self._load(); return
        if names: self.vcb.set(names[0]); self._load()

    def _load(self):
        vn=self.vcb.get()
        if not vn or vn not in self._vm: return
        fluids=self.db.get_fluids(self._vm[vn])
        for key,w in self._widgets.items(): w.delete(0,"end")
        self._notes.delete("1.0","end")
        if fluids:
            for key,w in self._widgets.items():
                val=fluids[key]
                if val: w.insert(0,val)
            if fluids["notes"]: self._notes.insert("1.0",fluids["notes"])

    def _save(self):
        vn=self.vcb.get()
        if not vn or vn not in self._vm:
            messagebox.showerror("Required","Select a vehicle."); return
        data={key:w.get().strip() for key,w in self._widgets.items()}
        data["notes"]=self._notes.get("1.0","end").strip()
        self.db.save_fluids(self._vm[vn],data)
        messagebox.showinfo("Saved","Fluid specs saved!")

    def refresh(self): self._load_vehicles()


# ============================================================
# NOTES
# ============================================================

class NotesPage(BasePage):
    def _build_ui(self):
        self._header("📝 Notes & Build Journal","Freeform notes per vehicle")
        fb=tk.Frame(self,bg=COLORS["bg_dark"],pady=8,padx=10); fb.pack(fill="x")
        tk.Label(fb,text="System:",font=FONT_LABEL,fg=COLORS["text_secondary"],bg=COLORS["bg_dark"]).pack(side="left",padx=(5,2))
        self.sys_cb=SC(fb,values=["All"]+NOTE_SYSTEMS,width=18); self.sys_cb.set("All")
        self.sys_cb.pack(side="left",padx=5)
        self.sys_cb.bind("<<ComboboxSelected>>",lambda e:self.refresh())

        tb=self._toolbar()
        SB(tb,"➕ Add Note", self._add,   COLORS["btn_primary"]).pack(side="left",padx=4)
        SB(tb,"✏️ Edit",     self._edit,  COLORS["btn_secondary"]).pack(side="left",padx=4)
        SB(tb,"🗑️ Delete",   self._delete,COLORS["btn_danger"]).pack(side="left",padx=4)
        SB(tb,"📤 Export CSV",self._export,"#1a5c5c").pack(side="right",padx=4)

        sp=tk.Frame(self,bg=COLORS["bg_medium"]); sp.pack(fill="both",expand=True)
        sp.columnconfigure(0,weight=3); sp.columnconfigure(1,weight=2)

        lf=tk.Frame(sp,bg=COLORS["bg_medium"]); lf.grid(row=0,column=0,sticky="nsew",padx=(10,5),pady=10)
        self.tree=make_tree(lf,["date","vehicle","title","system","lessons"],
                            ["Date","Vehicle","Title","System","Lessons Learned"],height=22)
        self.tree.column("date",width=90); self.tree.column("title",width=160)
        self.tree.bind("<<TreeviewSelect>>",self._preview)
        self.tree.bind("<Double-1>",lambda e:self._edit())

        pf=tk.Frame(sp,bg=COLORS["bg_dark"],padx=15,pady=10)
        pf.grid(row=0,column=1,sticky="nsew",padx=(5,10),pady=10)
        tk.Label(pf,text="📄 Preview",font=FONT_LABEL_BOLD,
                 fg=COLORS["accent"],bg=COLORS["bg_dark"]).pack(anchor="w",pady=(0,5))
        self._pt=tk.Label(pf,text="",font=FONT_SUBTITLE,fg=COLORS["text_primary"],
                           bg=COLORS["bg_dark"],wraplength=300,justify="left")
        self._pt.pack(anchor="w")
        self._pc=ST(pf,height=12); self._pc.pack(fill="both",expand=True,pady=5)
        self._pc.configure(state="disabled")
        self._pl=tk.Label(pf,text="",font=FONT_SMALL,fg=COLORS["warning"],
                           bg=COLORS["bg_dark"],wraplength=300,justify="left")
        self._pl.pack(anchor="w")

    def refresh(self):
        sys_=self.sys_cb.get(); sys_=None if sys_=="All" else sys_
        recs=self.db.get_notes(system=sys_)
        def fill():
            for i,r in enumerate(recs):
                tag="even" if i%2==0 else "odd"
                self.tree.insert("","end",iid=str(r["id"]),tags=(tag,),values=(
                    r["date"] or "",r["vehicle_name"],r["title"] or "",
                    r["system"] or "",(r["lessons_learned"] or "")[:60]))
        self.tree.repopulate(fill)

    def _preview(self,e=None):
        s=self.tree.selection()
        if not s: return
        r=self.db.conn.execute("SELECT * FROM notes WHERE id=?",(int(s[0]),)).fetchone()
        if not r: return
        self._pt.config(text=r["title"] or "")
        self._pc.configure(state="normal"); self._pc.delete("1.0","end")
        self._pc.insert("1.0",r["content"] or ""); self._pc.configure(state="disabled")
        ll=r["lessons_learned"] or ""
        self._pl.config(text=f"💡 {ll}" if ll else "")

    def _sel(self):
        s=self.tree.selection()
        if not s: self._no_selection(); return None
        return int(s[0])

    def _add(self):
        if not self.db.get_vehicles(): messagebox.showwarning("No Vehicles","Add a vehicle first."); return
        d=NoteDialog(self,self.app); self.wait_window(d); self.refresh()

    def _edit(self):
        nid=self._sel()
        if not nid: return
        r=self.db.conn.execute("SELECT * FROM notes WHERE id=?",(nid,)).fetchone()
        d=NoteDialog(self,self.app,r); self.wait_window(d); self.refresh()

    def _delete(self):
        nid=self._sel()
        if not nid: return
        if messagebox.askyesno("Delete","Delete this note?"):
            self.db.delete_note(nid); self.refresh()

    def _export(self):
        p=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="notes.csv")
        if p: self.db.export_table_csv("notes",p); messagebox.showinfo("Done",f"Saved to {p}")


class NoteDialog(tk.Toplevel):
    def __init__(self,parent,app,record=None):
        super().__init__(parent)
        self.app=app; self.db=app.db; self.rec=record
        self.title("Edit Note" if record else "Add Note")
        self.configure(bg=COLORS["bg_dark"]); self.geometry("700x640")
        self.resizable(True,True); self.grab_set()
        tk.Label(self,text="Build Journal / Note",font=FONT_SUBTITLE,
                 fg=COLORS["text_primary"],bg=COLORS["bg_light"],pady=10).pack(fill="x")
        sf=ScrollFrame(self,bg=COLORS["bg_dark"]); sf.pack(fill="both",expand=True)
        b=sf.inner; b.configure(bg=COLORS["bg_dark"])
        b.columnconfigure(1,weight=1); b.columnconfigure(3,weight=1)

        self._vm,vn=v_map(self.db)
        _lbl(b,"Vehicle *",True,COLORS["bg_dark"]).grid(row=0,column=0,padx=(15,5),pady=4,sticky="e")
        self.fv=SC(b,values=vn); self.fv.configure(state="readonly")
        self.fv.grid(row=0,column=1,padx=(0,15),pady=4,sticky="ew")
        self.fdt=field(b,"Date",row=0,col=1,bg=COLORS["bg_dark"])
        self.fdt.insert(0,today_str())
        self.ftit=field(b,"Title *",row=1,col=0,required=True,bg=COLORS["bg_dark"])
        self.fsys=field(b,"System","combo",row=1,col=1,values=NOTE_SYSTEMS,bg=COLORS["bg_dark"])
        _lbl(b,"Content *",True,COLORS["bg_dark"]).grid(row=2,column=0,padx=(15,5),pady=4,sticky="ne")
        self.fcon=ST(b,height=10); self.fcon.grid(row=2,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")
        _lbl(b,"💡 Lessons Learned",bg=COLORS["bg_dark"]).grid(row=3,column=0,padx=(15,5),pady=4,sticky="ne")
        self.fll=ST(b,height=4); self.fll.grid(row=3,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")

        if record: self._populate(record)
        elif app.selected_vehicle_id:
            v=self.db.get_vehicle(app.selected_vehicle_id)
            if v: self.fv.set(f"{v['year']} {v['make']} {v['model']}")

        bf=tk.Frame(self,bg=COLORS["bg_medium"],pady=10); bf.pack(fill="x",side="bottom")
        SB(bf,"Cancel",self.destroy,COLORS["btn_danger"]).pack(side="right",padx=10)
        SB(bf,"💾 Save",self._save,COLORS["btn_success"]).pack(side="right",padx=5)

    def _populate(self,r):
        v=self.db.get_vehicle(r["vehicle_id"])
        if v: self.fv.set(f"{v['year']} {v['make']} {v['model']}")
        self.fdt.delete(0,"end"); self.fdt.insert(0,r["date"] or today_str())
        self.ftit.delete(0,"end"); self.ftit.insert(0,r["title"] or "")
        if r["system"]: self.fsys.set(r["system"])
        if r["content"]: self.fcon.insert("1.0",r["content"])
        if r["lessons_learned"]: self.fll.insert("1.0",r["lessons_learned"])

    def _save(self):
        vn=self.fv.get(); tit=self.ftit.get().strip()
        if not vn or vn not in self._vm: messagebox.showerror("Required","Select a vehicle."); return
        if not tit: messagebox.showerror("Required","Title required."); return
        data={"vehicle_id":self._vm[vn],"date":self.fdt.get().strip() or today_str(),
              "title":tit,"system":self.fsys.get(),
              "content":self.fcon.get("1.0","end").strip(),
              "lessons_learned":self.fll.get("1.0","end").strip()}
        if self.rec: self.db.update_note(self.rec["id"],data)
        else:        self.db.add_note(data)
        self.destroy()


# ============================================================
# COST TRACKING
# ============================================================

class CostPage(BasePage):
    def _build_ui(self):
        self._header("💰 Cost Tracking","Financial summary across all vehicles")
        sb=tk.Frame(self,bg=COLORS["bg_dark"],pady=8,padx=15); sb.pack(fill="x")
        tk.Label(sb,text="Vehicle:",font=FONT_LABEL_BOLD,
                 fg=COLORS["text_primary"],bg=COLORS["bg_dark"]).pack(side="left",padx=5)
        self._vm={}
        self.vcb=SC(sb,width=32); self.vcb.pack(side="left",padx=10)
        self.vcb.bind("<<ComboboxSelected>>",lambda e:self.refresh())
        SB(sb,"🔄 Refresh",self.refresh,COLORS["btn_secondary"]).pack(side="left",padx=10)

        sf=ScrollFrame(self,bg=COLORS["bg_medium"]); sf.pack(fill="both",expand=True)
        self._body=sf.inner; self._body.configure(bg=COLORS["bg_medium"])

        self._load_vehicles()

    def _load_vehicles(self):
        m,names=v_map(self.db)
        self._vm={"All Vehicles":None,**m}
        names=["All Vehicles"]+names
        old=self.vcb.get()
        self.vcb["values"]=names
        self.vcb.set(old if old in names else "All Vehicles")

    def refresh(self):
        self._load_vehicles()
        for w in self._body.winfo_children(): w.destroy()
        vid=self._vm.get(self.vcb.get())
        s=self.db.get_cost_summary(vid)

        # Stat cards
        cf=tk.Frame(self._body,bg=COLORS["bg_medium"]); cf.pack(fill="x",padx=20,pady=15)
        for lbl,amt,col in [("🔩 Maintenance",s["maintenance"],COLORS["info"]),
                             ("🔧 Repairs",    s["repair"],    COLORS["danger"]),
                             ("⚡ Mods",       s["modifications"],COLORS["accent2"]),
                             ("📦 Parts",      s["parts"],     COLORS["warning"]),
                             ("💰 TOTAL",      s["total"],     COLORS["success"])]:
            card=tk.Frame(cf,bg=COLORS["bg_dark"],padx=22,pady=14); card.pack(side="left",padx=8)
            tk.Label(card,text=format_currency(amt),font=("Segoe UI",18,"bold"),
                     fg=col,bg=COLORS["bg_dark"]).pack()
            tk.Label(card,text=lbl,font=FONT_LABEL,
                     fg=COLORS["text_secondary"],bg=COLORS["bg_dark"]).pack()

        # Per-vehicle table
        tk.Label(self._body,text="Breakdown by Vehicle",font=FONT_SUBTITLE,
                 fg=COLORS["text_primary"],bg=COLORS["bg_medium"]).pack(padx=20,pady=(15,5),anchor="w")
        tf=tk.Frame(self._body,bg=COLORS["bg_dark"]); tf.pack(fill="x",padx=20,pady=5)
        headers=["Vehicle","Maintenance","Repairs","Mods","Parts","Total"]
        for i,h in enumerate(headers):
            tk.Label(tf,text=h,font=FONT_LABEL_BOLD,fg=COLORS["accent"],
                     bg=COLORS["bg_dark"],width=16,anchor="center",pady=6).grid(row=0,column=i,sticky="ew",padx=2)
        for ri,v in enumerate(self.db.get_vehicles()):
            c=self.db.get_cost_summary(v["id"])
            nm=f"{v['year']} {v['make']} {v['model']}"
            rbg=COLORS["table_bg"] if ri%2==0 else COLORS["table_alt"]
            row_vals=[nm,c["maintenance"],c["repair"],c["modifications"],c["parts"],c["total"]]
            for ci,val in enumerate(row_vals):
                txt=val if ci==0 else format_currency(val)
                fg=COLORS["text_primary"] if ci==0 else (COLORS["warning"] if ci==5 else COLORS["text_secondary"])
                tk.Label(tf,text=txt,font=FONT_LABEL,fg=fg,bg=rbg,
                         pady=5,padx=5,anchor="center").grid(row=ri+1,column=ci,sticky="ew",padx=2,pady=1)

        # Bar chart
        if s["total"]>0:
            tk.Label(self._body,text="Cost by Category",font=FONT_SUBTITLE,
                     fg=COLORS["text_primary"],bg=COLORS["bg_medium"]).pack(padx=20,pady=(15,5),anchor="w")
            self._draw_chart(s)

    def _draw_chart(self,s):
        cf=tk.Frame(self._body,bg=COLORS["bg_dark"],padx=20,pady=15)
        cf.pack(fill="x",padx=20,pady=10)
        canvas=tk.Canvas(cf,bg=COLORS["bg_dark"],height=220,highlightthickness=0)
        canvas.pack(fill="x")
        cats=[("Maintenance",s["maintenance"],COLORS["info"]),
              ("Repairs",    s["repair"],    COLORS["danger"]),
              ("Mods",       s["modifications"],COLORS["accent2"]),
              ("Parts",      s["parts"],     COLORS["warning"])]
        total=max(s["total"],1); bar_w=90; gap=50; sx=80; max_h=160
        for i,(lbl,amt,col) in enumerate(cats):
            x=sx+i*(bar_w+gap); h=int((amt/total)*max_h); y1=190; y0=y1-h
            canvas.create_rectangle(x,y0,x+bar_w,y1,fill=col,outline="",width=0)
            canvas.create_text(x+bar_w//2,y1+14,text=lbl,
                               fill=COLORS["text_secondary"],font=("Segoe UI",9))
            if amt>0:
                canvas.create_text(x+bar_w//2,y0-10,text=format_currency(amt),
                                   fill=COLORS["text_primary"],font=("Segoe UI",9,"bold"))


# ============================================================
# FUEL LOG
# ============================================================

class FuelPage(BasePage):
    def _build_ui(self):
        self._header("⛽ Fuel Log","Track fill-ups & MPG")
        sb=tk.Frame(self,bg=COLORS["bg_dark"],pady=8,padx=15); sb.pack(fill="x")
        self._vm={}
        tk.Label(sb,text="Vehicle:",font=FONT_LABEL_BOLD,
                 fg=COLORS["text_primary"],bg=COLORS["bg_dark"]).pack(side="left",padx=5)
        self.vcb=SC(sb,width=30); self.vcb.pack(side="left",padx=10)
        self.vcb.bind("<<ComboboxSelected>>",lambda e:self.refresh())

        tb=self._toolbar()
        SB(tb,"➕ Add Fuel-Up",self._add,   COLORS["btn_primary"]).pack(side="left",padx=4)
        SB(tb,"🗑️ Delete",      self._delete,COLORS["btn_danger"]).pack(side="left",padx=4)
        SB(tb,"📤 Export CSV",  self._export,"#1a5c5c").pack(side="right",padx=4)
        self._stat=tk.Label(tb,text="",font=FONT_LABEL_BOLD,fg=COLORS["success"],bg=COLORS["sidebar"])
        self._stat.pack(side="right",padx=15)

        self.tree=make_tree(self,
            ["date","mileage","gallons","ppg","total","mpg","station","notes"],
            ["Date","Mileage","Gallons","$/Gal","Total","MPG","Station","Notes"])
        self._load_vehicles()

    def _load_vehicles(self):
        self._vm,names=v_map(self.db)
        self.vcb["values"]=names
        if names:
            if self.app.selected_vehicle_id:
                v=self.db.get_vehicle(self.app.selected_vehicle_id)
                if v:
                    nm=f"{v['year']} {v['make']} {v['model']}"
                    if nm in self._vm: self.vcb.set(nm); return
            self.vcb.set(names[0])

    def refresh(self):
        self._load_vehicles()
        vn=self.vcb.get()
        if not vn or vn not in self._vm: return
        vid=self._vm[vn]; recs=self.db.get_fuel_log(vid)
        tc=0; tg=0; mpgs=[]; prev_mi=None
        def fill():
            nonlocal tc,tg,prev_mi
            for i,r in enumerate(recs):
                tag="even" if i%2==0 else "odd"
                mpg_txt=""
                if prev_mi and r["gallons"] and r["gallons"]>0:
                    miles=prev_mi-r["mileage"]
                    if miles>0:
                        mpv=miles/r["gallons"]; mpgs.append(mpv); mpg_txt=f"{mpv:.1f}"
                prev_mi=r["mileage"]
                tc+=r["total_cost"] or 0; tg+=r["gallons"] or 0
                self.tree.insert("","end",iid=str(r["id"]),tags=(tag,),values=(
                    r["date"],format_mileage(r["mileage"]),
                    f"{r['gallons']:.3f}" if r["gallons"] else "",
                    format_currency(r["price_per_gallon"]),
                    format_currency(r["total_cost"]),
                    mpg_txt,r["station"] or "",(r["notes"] or "")[:30]))
        self.tree.repopulate(fill)
        avg=sum(mpgs)/len(mpgs) if mpgs else 0
        self._stat.config(text=f"Avg MPG: {avg:.1f} | Total: {format_currency(tc)} | {tg:.1f} gal")

    def _sel(self):
        s=self.tree.selection()
        if not s: return None
        return int(s[0])

    def _add(self):
        vn=self.vcb.get()
        if not vn or vn not in self._vm:
            messagebox.showwarning("Select Vehicle","Please select a vehicle first."); return
        d=FuelDialog(self,self.app,self._vm[vn]); self.wait_window(d); self.refresh()

    def _delete(self):
        fid=self._sel()
        if not fid: self._no_selection(); return
        if messagebox.askyesno("Delete","Delete this fuel record?"):
            self.db.delete_fuel(fid); self.refresh()

    def _export(self):
        p=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="fuel_log.csv")
        if p: self.db.export_table_csv("fuel_log",p); messagebox.showinfo("Done",f"Saved to {p}")


class FuelDialog(tk.Toplevel):
    def __init__(self,parent,app,vehicle_id):
        super().__init__(parent)
        self.app=app; self.db=app.db; self.vid=vehicle_id
        self.title("Add Fuel-Up")
        self.configure(bg=COLORS["bg_dark"]); self.geometry("500x440"); self.grab_set()
        tk.Label(self,text="Fuel Log Entry",font=FONT_SUBTITLE,
                 fg=COLORS["text_primary"],bg=COLORS["bg_light"],pady=10).pack(fill="x")
        b=tk.Frame(self,bg=COLORS["bg_dark"]); b.pack(fill="both",expand=True,padx=20,pady=10)
        b.columnconfigure(1,weight=1); b.columnconfigure(3,weight=1)
        self.fdt=field(b,"Date",row=0,col=0,bg=COLORS["bg_dark"])
        self.fdt.insert(0,today_str())
        self.fmi=field(b,"Mileage",row=0,col=1,bg=COLORS["bg_dark"])
        self.fga=field(b,"Gallons",row=1,col=0,bg=COLORS["bg_dark"])
        self.fpp=field(b,"Price / Gallon ($)",row=1,col=1,bg=COLORS["bg_dark"])
        self.fto=field(b,"Total Cost ($)",row=2,col=0,bg=COLORS["bg_dark"])
        self.fst=field(b,"Station",row=2,col=1,bg=COLORS["bg_dark"])
        SB(b,"⚡ Auto-calc Total",self._calc,COLORS["btn_secondary"]).grid(row=3,column=0,columnspan=4,pady=8,padx=15)
        _lbl(b,"Notes",bg=COLORS["bg_dark"]).grid(row=4,column=0,padx=(15,5),pady=4,sticky="ne")
        self.fno=ST(b,height=3); self.fno.grid(row=4,column=1,columnspan=3,padx=(0,15),pady=4,sticky="ew")

        bf=tk.Frame(self,bg=COLORS["bg_medium"],pady=10); bf.pack(fill="x",side="bottom")
        SB(bf,"Cancel",self.destroy,COLORS["btn_danger"]).pack(side="right",padx=10)
        SB(bf,"💾 Save",self._save,COLORS["btn_success"]).pack(side="right",padx=5)

    def _calc(self):
        try:
            g=float(self.fga.get() or 0); p=float(self.fpp.get() or 0)
            self.fto.delete(0,"end"); self.fto.insert(0,f"{g*p:.2f}")
        except: pass

    def _save(self):
        mi=self.fmi.get().strip()
        data={"vehicle_id":self.vid,"date":self.fdt.get().strip() or today_str(),
              "mileage":int(mi) if mi.isdigit() else 0,
              "gallons":float(self.fga.get().strip() or 0),
              "price_per_gallon":float(self.fpp.get().strip() or 0),
              "total_cost":float(self.fto.get().strip() or 0),
              "station":self.fst.get().strip(),"notes":self.fno.get("1.0","end").strip()}
        self.db.add_fuel(data); self.destroy()


# ============================================================
# MAIN APPLICATION
# ============================================================

class GarageTracker:
    def __init__(self):
        self.root=tk.Tk()
        self.root.title(f"{APP_NAME} v{APP_VERSION}")
        self.root.geometry("1280x820")
        self.root.minsize(960,640)
        self.root.configure(bg=COLORS["bg_dark"])

        self.db=Database()
        self.selected_vehicle_id=None

        self._apply_style()
        self._build_ui()
        self._build_menu()

        # Auto-select first vehicle
        vehicles=self.db.get_vehicles()
        if vehicles:
            self.selected_vehicle_id=vehicles[0]["id"]
            self.update_vehicle_selector()

        self.navigate("dashboard")
        self.root.protocol("WM_DELETE_WINDOW",self._close)

    # ---- Styles ----
    def _apply_style(self):
        s=ttk.Style(); s.theme_use("clam")
        s.configure("Treeview",
            background=COLORS["table_bg"],foreground=COLORS["text_primary"],
            rowheight=26,fieldbackground=COLORS["table_bg"],borderwidth=0,font=FONT_SMALL)
        s.configure("Treeview.Heading",
            background=COLORS["bg_light"],foreground=COLORS["text_primary"],
            font=FONT_LABEL_BOLD,borderwidth=0,relief="flat")
        s.map("Treeview",
            background=[("selected",COLORS["table_select"])],
            foreground=[("selected",COLORS["text_primary"])])
        s.map("Treeview.Heading",background=[("active",COLORS["accent2"])])
        s.configure("TCombobox",
            background=COLORS["entry_bg"],foreground=COLORS["text_primary"],
            fieldbackground=COLORS["entry_bg"],selectbackground=COLORS["table_select"],
            selectforeground=COLORS["text_primary"],arrowcolor=COLORS["text_primary"],borderwidth=0)
        s.map("TCombobox",
            fieldbackground=[("readonly",COLORS["entry_bg"])],
            foreground=[("readonly",COLORS["text_primary"])],
            selectbackground=[("readonly",COLORS["table_select"])])
        s.configure("Vertical.TScrollbar",
            background=COLORS["bg_light"],troughcolor=COLORS["bg_dark"],
            arrowcolor=COLORS["text_secondary"],borderwidth=0,relief="flat")
        s.configure("Horizontal.TScrollbar",
            background=COLORS["bg_light"],troughcolor=COLORS["bg_dark"],
            arrowcolor=COLORS["text_secondary"],borderwidth=0,relief="flat")
        self.root.option_add("*TCombobox*Listbox.background",  COLORS["entry_bg"])
        self.root.option_add("*TCombobox*Listbox.foreground",  COLORS["text_primary"])
        self.root.option_add("*TCombobox*Listbox.selectBackground",COLORS["table_select"])
        self.root.option_add("*TCombobox*Listbox.font",        FONT_LABEL)

    # ---- UI ----
    def _build_ui(self):
        main=tk.Frame(self.root,bg=COLORS["bg_dark"]); main.pack(fill="both",expand=True)

        # Sidebar
        self._sidebar=tk.Frame(main,bg=COLORS["sidebar"],width=210); self._sidebar.pack(side="left",fill="y")
        self._sidebar.pack_propagate(False)

        logo=tk.Frame(self._sidebar,bg=COLORS["accent"],pady=14); logo.pack(fill="x")
        tk.Label(logo,text="🏎️",font=("Segoe UI",24),fg="white",bg=COLORS["accent"]).pack()
        tk.Label(logo,text="GARAGE TRACKER",font=("Segoe UI",11,"bold"),fg="white",bg=COLORS["accent"]).pack()

        vsf=tk.Frame(self._sidebar,bg=COLORS["sidebar"],pady=8,padx=8); vsf.pack(fill="x")
        tk.Label(vsf,text="Active Vehicle",font=FONT_SMALL,
                 fg=COLORS["text_muted"],bg=COLORS["sidebar"]).pack(anchor="w")
        self._vcb=SC(vsf,width=24); self._vcb.pack(fill="x",pady=3)
        self._vcb.bind("<<ComboboxSelected>>",self._on_v_select)

        nav=tk.Frame(self._sidebar,bg=COLORS["sidebar"]); nav.pack(fill="both",expand=True,pady=8)
        self._nav_btns={}
        self._cur_page=None

        items=[("🏠  Dashboard","dashboard"),("🚗  Garage","vehicles"),
               ("🔩  Maintenance","maintenance"),("📅  Schedule","schedule"),
               ("⚡  Modifications","modifications"),("🔧  Repairs","repairs"),
               ("📦  Parts","parts"),("🧪  Fluids & Specs","fluids"),
               ("📝  Notes","notes"),("💰  Costs","costs"),("⛽  Fuel Log","fuel")]

        for lbl,pg in items:
            btn=tk.Button(nav,text=lbl,command=lambda p=pg:self.navigate(p),
                bg=COLORS["sidebar"],fg=COLORS["text_primary"],font=FONT_LABEL,
                relief="flat",bd=0,anchor="w",padx=14,pady=9,cursor="hand2",
                width=24,activebackground=COLORS["sidebar_hover"],
                activeforeground=COLORS["text_primary"])
            btn.pack(fill="x")
            btn.bind("<Enter>",lambda e,b=btn:b.config(bg=COLORS["sidebar_hover"]))
            btn.bind("<Leave>",lambda e,b=btn,p=pg:
                     b.config(bg=COLORS["accent"] if self._cur_page==p else COLORS["sidebar"]))
            self._nav_btns[pg]=btn

        tk.Label(self._sidebar,text=f"v{APP_VERSION}  •  Data: {os.path.basename(DB_FILE)}",
                 font=("Segoe UI",8),fg=COLORS["text_muted"],
                 bg=COLORS["sidebar"],wraplength=190).pack(side="bottom",pady=6)

        # Content
        self._content=tk.Frame(main,bg=COLORS["bg_medium"]); self._content.pack(side="left",fill="both",expand=True)
        self._pages={}

    # ---- Menu ----
    def _build_menu(self):
        mb=tk.Menu(self.root,bg=COLORS["bg_dark"],fg=COLORS["text_primary"],
                   activebackground=COLORS["bg_light"],activeforeground=COLORS["text_primary"],
                   relief="flat",bd=0)
        fm=tk.Menu(mb,tearoff=0,bg=COLORS["bg_dark"],fg=COLORS["text_primary"],
                   activebackground=COLORS["table_select"],activeforeground=COLORS["text_primary"])
        fm.add_command(label="🔄  Refresh",          command=self._refresh)
        fm.add_separator()
        fm.add_command(label="💾  Backup Database",  command=self._backup)
        fm.add_command(label="📂  Restore Database", command=self._restore)
        fm.add_separator()
        fm.add_command(label="📤  Export All to CSV",command=self._export_all)
        fm.add_separator()
        fm.add_command(label="❌  Exit",              command=self._close)
        mb.add_cascade(label="File",menu=fm)

        hm=tk.Menu(mb,tearoff=0,bg=COLORS["bg_dark"],fg=COLORS["text_primary"],
                   activebackground=COLORS["table_select"],activeforeground=COLORS["text_primary"])
        hm.add_command(label="ℹ️  About",             command=self._about)
        hm.add_command(label="📁  Database Location", command=self._db_loc)
        mb.add_cascade(label="Help",menu=hm)
        self.root.config(menu=mb)

    # ---- Navigation ----
    def navigate(self, pg):
        if self._cur_page and self._cur_page in self._nav_btns:
            self._nav_btns[self._cur_page].config(bg=COLORS["sidebar"])
        if pg in self._nav_btns:
            self._nav_btns[pg].config(bg=COLORS["accent"])
        self._cur_page=pg

        if pg not in self._pages:
            cls={"dashboard":DashboardPage,"vehicles":VehiclesPage,
                 "maintenance":MaintenancePage,"schedule":SchedulePage,
                 "modifications":ModificationsPage,"repairs":RepairsPage,
                 "parts":PartsPage,"fluids":FluidsPage,"notes":NotesPage,
                 "costs":CostPage,"fuel":FuelPage}.get(pg)
            if not cls: return
            self._pages[pg]=cls(self._content,self)

        for p in self._pages.values(): p.pack_forget()
        self._pages[pg].pack(fill="both",expand=True)
        self._pages[pg].refresh()

    def update_vehicle_selector(self):
        m,names=v_map(self.db); self._vcb_map=m
        self._vcb["values"]=names
        if self.selected_vehicle_id:
            v=self.db.get_vehicle(self.selected_vehicle_id)
            if v: self._vcb.set(f"{v['year']} {v['make']} {v['model']}"); return
        if names: self._vcb.set(names[0])

    def _on_v_select(self,e=None):
        vn=self._vcb.get()
        if vn and hasattr(self,"_vcb_map"):
            self.selected_vehicle_id=self._vcb_map.get(vn)
        self._refresh()

    def _refresh(self):
        if self._cur_page and self._cur_page in self._pages:
            self._pages[self._cur_page].refresh()

    # ---- File menu ----
    def _backup(self):
        p=filedialog.asksaveasfilename(
            defaultextension=".db",filetypes=[("SQLite DB","*.db"),("All","*.*")],
            initialfile=f"garage_tracker_backup_{date.today().isoformat()}.db",
            title="Save Backup")
        if p:
            try: self.db.backup(p); messagebox.showinfo("Backup","Backed up to:\n"+p)
            except Exception as e: messagebox.showerror("Error",str(e))

    def _restore(self):
        if not messagebox.askyesno("Restore",
            "This will REPLACE your current database.\nMake a backup first!\n\nContinue?"): return
        p=filedialog.askopenfilename(filetypes=[("SQLite DB","*.db"),("All","*.*")])
        if p:
            try:
                self.db.close(); shutil.copy2(p,DB_FILE)
                messagebox.showinfo("Restored","Restored. Please restart Garage Tracker.")
                self.root.quit()
            except Exception as e: messagebox.showerror("Error",str(e))

    def _export_all(self):
        folder=filedialog.askdirectory(title="Select folder for CSV exports")
        if not folder: return
        tables=["vehicles","maintenance","service_schedule","modifications",
                "repairs","parts","fluids","notes","fuel_log"]
        done=sum(1 for t in tables if self.db.export_table_csv(t,os.path.join(folder,f"{t}.csv")))
        messagebox.showinfo("Export",f"Exported {done} tables to:\n{folder}")

    def _about(self):
        messagebox.showinfo(f"About {APP_NAME}",
            f"{APP_NAME} v{APP_VERSION}\n\n"
            "A complete local car care & maintenance tracker.\n"
            "All data is stored offline on your computer.\n\n"
            f"Database:\n{DB_FILE}\n\n"
            "Features: Vehicle Garage · Maintenance Log · Service\n"
            "Reminders · Modifications · Repairs · Parts Inventory\n"
            "Fluids & Specs · Build Journal · Cost Tracking · Fuel Log")

    def _db_loc(self):
        messagebox.showinfo("Database Location",f"Your database is at:\n\n{DB_FILE}")

    def _close(self):
        self.db.close(); self.root.destroy()

    def run(self):
        self.root.mainloop()


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    app = GarageTracker()
    app.run()
