@echo off
title Garage Tracker - Auto Builder
color 0A
echo.
echo ============================================================
echo   GARAGE TRACKER - Windows 11 Auto Builder
echo   Do not close this window until it says DONE
echo ============================================================
echo.

:: ---- Check Python ----
echo [1/4] Checking for Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo Python not found. Opening download page...
    echo Please install Python from python.org, then re-run this file.
    echo IMPORTANT: Check "Add Python to PATH" during install!
    start https://www.python.org/downloads/
    pause
    exit /b
)
echo       Python found OK.

:: ---- Install PyInstaller ----
echo.
echo [2/4] Installing PyInstaller (this may take a minute)...
python -m pip install pyinstaller --quiet --disable-pip-version-check
if errorlevel 1 (
    echo ERROR installing PyInstaller. Check your internet connection.
    pause
    exit /b
)
echo       PyInstaller ready.

:: ---- Build the EXE ----
echo.
echo [3/4] Building GarageTracker.exe (30-60 seconds)...
python -m PyInstaller --onefile --windowed --name "GarageTracker" --clean garage_tracker.py
if errorlevel 1 (
    echo ERROR during build. Make sure garage_tracker.py is in this same folder.
    pause
    exit /b
)
echo       Build complete!

:: ---- Copy EXE and create Desktop shortcut ----
echo.
echo [4/4] Installing to Desktop...

:: Copy exe to current folder for easy access
copy /Y "dist\GarageTracker.exe" "GarageTracker.exe" >nul

:: Create Desktop shortcut using PowerShell
set DESKTOP=%USERPROFILE%\Desktop
set EXEPATH=%CD%\GarageTracker.exe

powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%DESKTOP%\GarageTracker.lnk'); $s.TargetPath = '%EXEPATH%'; $s.WorkingDirectory = '%CD%'; $s.Description = 'Garage Tracker - Car Maintenance App'; $s.Save()"

echo.
echo ============================================================
echo   DONE!
echo.
echo   GarageTracker.exe is now in this folder AND on your Desktop.
echo   Double-click the Desktop icon to launch the app.
echo.
echo   Your data is saved to:
echo   %USERPROFILE%\garage_tracker.db
echo ============================================================
echo.
pause
